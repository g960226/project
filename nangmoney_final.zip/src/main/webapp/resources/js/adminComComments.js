function deleteComComments (event) {
	const idx= event.target.getAttribute('idx')
	const flag = confirm('정말 삭제하시겠습니까?')
	if(flag) {
		location.href = cpath + '/delete_Comcomments/' + idx
	}
}
	
const deleteBtnList = document.querySelectorAll('.deleteBtn')
deleteBtnList.forEach(e => e.onclick = deleteComComments)

const toComu = document.querySelectorAll('tr.toComu')
toComu.forEach(e => {
	e.onclick = toCommunity
})

function toCommunity(event) {
	let target = event.target	
	if(target.querySelector('button') != null || target.getAttribute('id') == 'deleteCommentsBtn') return	// id라는 속성이 있다면 리턴(button 클릭했을 때 요청주소로 못날아가게)
	while(target.getAttribute('idx') == null){	// 클릭한 타겟에 idx속성이 있다면(있을 때까지)
		target = target.parentNode	// 타겟을 상위 노드로 재설정한다 (있을 때까지)
	}
	const idx = target.getAttribute('idx')	// 그 다음 idx(게시글idx)를 구해서
	location.href= cpath + '/community/view/'+idx	// 게시글 요청주소로 보냄
}