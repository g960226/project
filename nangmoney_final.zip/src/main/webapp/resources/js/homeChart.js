function showChart() {
		const url = cpath + '/chart'
		fetch(url)
		.then (resp => resp.json())
		.then (json => {
			const arr = [
				{ingredient:'소고기', count:json[0].beef},
				{ingredient:'돼지고기', count:json[0].pork},
				{ingredient:'닭고기', count:json[0].chicken},
				{ingredient:'고기류', count:json[0].meat},
				{ingredient:'햄', count:json[0].ham},
				{ingredient:'참치', count:json[0].tuna},
				{ingredient:'연어', count:json[0].salmon},
				{ingredient:'해물류', count:json[0].seafood},
				{ingredient:'빵_밀가루', count:json[0].bread},
				{ingredient:'해조류', count:json[0].algae},
				{ingredient:'두부', count:json[0].tofu},
				{ingredient:'어묵', count:json[0].fishCake},
				{ingredient:'김치', count:json[0].kimchi},
				{ingredient:'양파', count:json[0].onion},
				{ingredient:'버섯', count:json[0].mushroom},
				{ingredient:'유제품_계란', count:json[0].egg},
				{ingredient:'마늘', count:json[0].garlic},
				{ingredient:'파', count:json[0].greenOnion},
				{ingredient:'감자', count:json[0].potato},
				{ingredient:'고추', count:json[0].pepper},
				{ingredient:'애호박', count:json[0].squash},
				{ingredient:'채소류', count:json[0].vegetables}
			]
			arr.sort((a, b) => a.count < b.count ? 1 : -1)
			const context = document.getElementById('myChart')
	 		const labels = arr.map(e => e.ingredient)
	 		const data = {
	 			labels: labels,
	 			datasets: [
	 				{
	 					label: '',
	 					data: arr.map(e => e.count),
	 					backgroundColor: [
	 				      'rgba(255, 99, 132, 0.2)',
	 				      'rgba(255, 159, 64, 0.2)',
	 				      'rgba(255, 205, 86, 0.2)',
	 				      'rgba(75, 192, 192, 0.2)',
	 				      'rgba(54, 162, 235, 0.2)',
	 				      'rgba(153, 102, 255, 0.2)',
	 				      'rgba(201, 203, 207, 0.2)'
	 					],
	 					borderColor: [
	 				      'rgb(255, 99, 132)',
	 				      'rgb(255, 159, 64)',
	 				      'rgb(255, 205, 86)',
	 				      'rgb(75, 192, 192)',
	 				      'rgb(54, 162, 235)',
	 				      'rgb(153, 102, 255)',
	 				      'rgb(201, 203, 207)'
	 				    ],
	 				    borderWidth: 1
	 				}
	 			]
	 		}
	 		const config = {
	 			type: 'bar',
	 			data: data,
	 			options: {
	 		        plugins: {
	 		            legend: {
	 		            	display: false
	 		            }
	 		        }
	 		    }
	 		}
	 		const myChart = new Chart(context, config)	
		})		
	}