	function withdrawMember (event) {
		const idx = event.target.getAttribute('idx')
	    const flag = confirm('정말 탈퇴하시겠습니까?')
	    if(flag) {
	       location.href = cpath + '/withdraw_member'
	    }
	 }
	const deleteBtnMypage = document.querySelectorAll('.deleteBtnMypage')
	deleteBtnMypage.forEach(e => e.onclick = withdrawMember)
