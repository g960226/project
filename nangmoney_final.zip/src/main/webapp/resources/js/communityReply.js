function comuCommentsHTMLfromJSON(dto) {

	const margin = dto.reply_depth * 30

	   let html = `<div class="comuComments" idx="${dto.comuCommentsIdx}" id="comuCommentsId" reply_depth="${dto.reply_depth}" style="margin-left: ${margin}px">`
	   html += `      <div class="comuCommentsTop">`
	   html += `         <div class="left">`
	   html += `            <div class="nickName">${dto.nickName}</div>`
	   html += `            <div class="comuCommentsDate">${getYMD(dto.comuCommentsDate)}</div>`
	   html += `         </div>`
	   html += `         <div class="right">`
	   html += `			<button class="rreply" ${loginNickName == '' ? 'hidden' : ''}>답변</button>`
	   html += `            <button class="delete" ${loginNickName != dto.nickName ? 'hidden' : ''}>삭제</button>`
	   html += `         </div>`
	   html += `      </div>`
	   html += `      <div class="comuMemo">${dto.comuMemo}</div>`
	   html += `</div>`
	return html   
}

function getYMD(date) {
	   const d = new Date(date)
	   const yyyy = d.getFullYear()
	   let mm = d.getMonth() + 1
	   let dd = d.getDate()
	   if(mm < 10) {
	      mm = '0' + mm
	   }
	   if(dd < 10) {
	      dd = '0' + dd
	   }
	   return `${yyyy}-${mm}-${dd}`
	}


async function comuCommentsLoadHandler() {
	const comuCommentsDiv = document.getElementById('comuComments')
	const url = cpath + '/community/comuComments/' + communityIdx
	console.log(url)
	
	await fetch(url)
	.then(resp => resp.json())
	.then(json => {
		const comuArrComments = json
		comuCommentsDiv.innerHTML = ''
			
		comuArrComments.forEach(dto => {
			const html = comuCommentsHTMLfromJSON(dto)
			comuCommentsDiv.innerHTML += html
		})
	})
	
	const deleteBtnList = document.querySelectorAll('button.delete')
	deleteBtnList.forEach(btn => btn.onclick = deleteHandler)	
	
	const rreplyBtnList = document.querySelectorAll('button.rreply')
	rreplyBtnList.forEach(btn => btn.onclick = rreplyHandler)
	
}

function rreplyHandler(event) {
	event.preventDefault()
	const form = document.getElementById('commentsWriteForm')
	const comuComments = event.target.parentNode.parentNode.parentNode
	
	form.querySelector('input[name="parent_idx"]').value = comuComments.getAttribute('idx')
	form.querySelector('input[name="reply_depth"]').value = +comuComments.getAttribute('reply_depth') + 1
	
	document.querySelectorAll('.comucomments').forEach(comuComments => comuComments.classList.remove('select'))
	comuComments.classList.add('select')
	comuComments.appendChild(form)
	form.querySelector('textarea').focus()
}


function comuCommentsWriteHandler(event) {
	event.preventDefault()
	const content = document.querySelector('#commentsWriteForm textarea')
	const content2 = document.querySelector('#commentsWriteForm select')
	const ob = {
		communityIdx: communityIdx,
		userIdx: loginUserIdx,
		nickName: loginNickName,
		comuMemo: content.value,
		parent_idx: event.target.querySelector('input[name="parent_idx"]').value,
		reply_depth: event.target.querySelector('input[name="reply_depth"]').value,
	}
	console.log(ob)
	const url = cpath + '/community/comuComments/' + communityIdx
	const opt = {
		method: 'POST',
		body: JSON.stringify(ob),
		headers: {
			'Content-Type': 'application/json; charset=utf-8'
		}
	}
	fetch(url, opt)
	.then(resp => resp.text())
	.then(text => {
		if(text == 1) {
			alert('작성성공!!')
			location.reload()
			content.value= ''
		}
	})
}

function deleteHandler(event) {
	const commentsWriter = event.target.parentNode.parentNode.querySelector('.nickName')
	console.log(loginNickName, commentsWriter.innerText)
	if(loginNickName != commentsWriter.innerText) {
		alert('본인이 작성한 댓글만 삭제할 수 있습니다')
		return
	}else {
		const flag = confirm('정말 삭제하겠습니까?')
		if(flag) {
			const idx = commentsWriter.parentNode.parentNode.parentNode.getAttribute('idx')
			const url = `${cpath}/community/comuComments/${communityIdx}/${idx}`
			const opt = {
				method: 'DELETE'
			}
			fetch(url, opt)
			.then(resp => resp.text())
			.then(text => {
				if(text == 1) {
					alert('삭제 완료!')
					location.reload()
					commentsLoadHandler()
				}
			})
		}
	}
}