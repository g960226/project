// 썸네일 미리보기
const input = document.querySelector('input[name="uploadThumbNail"]')
const preview = document.getElementById('preview')

function changeHandler(event) {
    if(event.target.files && event.target.files[0]) {
        preview.style.height = '300px'
        const reader = new FileReader()
        reader.onload = function(e) {
            preview.style.backgroundImage = 'url('+ e.target.result + ')'
        }
        reader.readAsDataURL(event.target.files[0])
    }
    else {
        preview.style.backgroundImage = ''
    }
}

input.onchange = changeHandler
preview.ondragover = () => preview.style.height = 0