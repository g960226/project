function categoryHTMLfromJSON(dto) {	
	let html = `		<div class="item">`
	html += `			<div class="thmb">`
	html += `				<a href="${cpath }/category/category_detail/${dto.recipeIdx}?flag=false"><div class="img">`
	html += `					<div class="scale">`
	html += `						<img src="${cpath }/nangmoney_t_img/${dto.recipeThumbNail }">`
	html += `					</div>`
	html += `				</div></a>`
	html += `			</div>`
	html += `			<div class="info">`
	html += `				<div class="info_tag"><span>조회수 : ${dto.views } </span><span>평점 : ${dto.score }</span><span>좋아요 : ${dto.likeSum }</span></div>`
	html += `				<div class="info_title ellip">`
	html += `					<a href="${cpath }/category/category_detail/${dto.recipeIdx}?flag=false">${dto.recipeName }</a>`
	html += `				</div>`
	html += `			</div>`
	html += `		</div>`
	return html
}

function nullPageHTML() {
	let html = `<div class="nullPage">`
	html += `		<div class="nullPageImg">`
	html += `			<img src="${cpath}/resources/image/no_data.png" style="margin-left: 110px !important; padding: 30px 0px !important;">`
	html += `		</div>`
	html += `	</div>`
	console.log(html)
	return html
}

//ingredient1 함수
function ingreClickHandler(event) {	
	const ingredientTarget = event.target
	// 클릭한 곳의 value값을 가져온다.
	const ingredientValue = event.target.innerText
	if(ingredientValue == '전체') {
	sessionStorage.removeItem('result')
		
	ingredient1.forEach(a => a.classList.remove('active'))
	    
 	ingredientTarget.classList.add('active')
 	
 	reloadrecipe()
 	
 	return
	}
	
	sessionStorage.removeItem('result') 
	
	ingredient1.forEach(a => a.classList.remove('active'))
 
	ingredientTarget.classList.add('active')    
 
 // 세션스토리지에 잠시 필요한 value값을 저장한 후 반환한다.
	sessionStorage.setItem('result', ingredientValue)
	
	reloadrecipe()
}

//ingredient2 함수
function ingreClick2Handler(event) {
	// class를 active로 바꾸는 용으로 사용
	const ingredientTarget = event.target
	// 클릭한 곳의 value값을 가져온다.
	const ingredientValue = event.target.innerText
	
	if(ingredientValue == '전체') {
	sessionStorage.removeItem('result2')
		
	ingredient2.forEach(a => a.classList.remove('active'))
	    
 	ingredientTarget.classList.add('active')
 	
 	reloadrecipe()
 	
 	return
	}
	
	sessionStorage.removeItem('result2')
	
	ingredient2.forEach(a => a.classList.remove('active'))
 
	ingredientTarget.classList.add('active')    
 
 // 세션스토리지에 잠시 필요한 value값을 저장한 후 반환한다.
	sessionStorage.setItem('result2', ingredientValue)
	reloadrecipe()
}

//ingredient3 함수
function ingreClick3Handler(event) {
	const ingredientTarget = event.target

	const ingredientValue = event.target.innerText
	
	if(ingredientValue == '전체') {
	sessionStorage.removeItem('result3')
		
	ingredient3.forEach(a => a.classList.remove('active'))
	    
 	ingredientTarget.classList.add('active')
 	
 	reloadrecipe()
 	
 	return
	}
	
	sessionStorage.removeItem('result3')
	
	ingredient3.forEach(a => a.classList.remove('active'))
 
	ingredientTarget.classList.add('active')
 
	sessionStorage.setItem('result3', ingredientValue)
	reloadrecipe()
}

//hand 함수
function handHandler(event) {
	const ingredientTarget = event.target

	const ingredientValue = event.target.innerText
	
	if(ingredientValue == '전체') {
	sessionStorage.removeItem('result4')
		
	hand.forEach(a => a.classList.remove('active'))
 
 	ingredientTarget.classList.add('active')
 	
 	reloadrecipe()
 	
 	return
	}
	
	sessionStorage.removeItem('result4')
	
	hand.forEach(a => a.classList.remove('active'))
 
	ingredientTarget.classList.add('active')
 
	sessionStorage.setItem('result4', ingredientValue)
	
	reloadrecipe()
}

function reloadrecipe() {
	const ingredient1Result = sessionStorage.getItem('result')
	const ingredient2Result = sessionStorage.getItem('result2')
	const ingredient3Result = sessionStorage.getItem('result3')
	const handResult = sessionStorage.getItem('result4')
	
	const categoryDiv = document.getElementById('categoryHTML') 
	const ob = {
			ingredient1: ingredient1Result,
			ingredient2: ingredient2Result,
			ingredient3: ingredient3Result,
			hand: handResult
	}
	getListRecipe(ob)
}

	//각각의 재료1을 가져온다.
	const ingredient1 = Array.from(document.querySelectorAll('#ingredient1 > div'))
	const ingredient2 = Array.from(document.querySelectorAll('#ingredient2 > div'))
	const ingredient3 = Array.from(document.querySelectorAll('#ingredient3 > div'))
	const hand = Array.from(document.querySelectorAll('#hand > div'))
	
	// 세션스토리지의 getItem을 이용하여 value값을 가져온다.
	const ingredient1Result = sessionStorage.getItem('result')
	const ingredient2Result = sessionStorage.getItem('result2')
	const ingredient3Result = sessionStorage.getItem('result3')
	const handResult = sessionStorage.getItem('result4')
	
	const categoryDiv = document.getElementById('categoryHTML') 
	const ob = {
			ingredient1: ingredient1Result,
			ingredient2: ingredient2Result,
			ingredient3: ingredient3Result,
			hand: handResult
	}
	
	function getListRecipe(ob) {
		const url = cpath + '/category/category_recipe/'
		const opt = {
				method: 'POST',
				body: JSON.stringify(ob),
				headers: {
					'Content-Type': 'application/json; charset=utf-8'
				}
		}
		fetch(url, opt)
		.then(resp => resp.json())
		.then(json => {
			const arr = json
			categoryDiv.innerHTML = ''
			if(arr.length != 0) {
				arr.forEach(dto => {
					const html = categoryHTMLfromJSON(dto)
					categoryDiv.innerHTML += html					
				})
			}
			else {
				const html = nullPageHTML()
				categoryDiv.innerHTML += html
			}
		})
	}	

	// 2. onclick 이벤트 함수를 생성
	ingredient1.forEach(e => e.onclick = ingreClickHandler)
	ingredient2.forEach(e => e.onclick = ingreClick2Handler)
	ingredient3.forEach(e => e.onclick = ingreClick3Handler)
	hand.forEach(e => e.onclick = handHandler)	
	

// ================================================================================
// 수정 삭제 구현하기
// css 수정하기


function deleteHandler(event) {
	const commentsWriter = event.target.parentNode.parentNode.querySelector('.nickName')
	console.log(loginNickName, commentsWriter.innerText)
	if(loginNickName != commentsWriter.innerText) {
		alert('본인이 작성한 댓글만 삭제할 수 있습니다')
		return
	}else {
		const flag = confirm('정말 삭제하겠습니까?')
		if(flag) {
			const idx = commentsWriter.parentNode.parentNode.parentNode.getAttribute('idx')
			const url = `${cpath}/category/comments/${recipeIdx}/${idx}`
			const opt = {
				method: 'DELETE'
			}
			fetch(url, opt)
			.then(resp => resp.text())
			.then(text => {
				if(text == 1) {
					alert('삭제 완료!')
					commentsLoadHandler()
					location.reload()
				}
			})
		}
	}
}

function commentsHTMLfromJSON(dto) {
	   let html = `<div class="comments" idx="${dto.commentsIdx}" id="commentsId">`
	   html += `      <div class="commentsTop">`
	   html += `         <div class="left">`
	   html += `            <div class="nickName">${dto.nickName}</div>`
	   html += `            <div class="commentsDate">${getYMD(dto.commentsDate)}</div>`
	   html += `         </div>`
	   html += `         <div class="right">`
	   html += `            <button class="delete" ${loginNickName != dto.nickName ? 'hidden' : ''}>삭제</button>`
	   html += `         </div>`
	   html += `      </div>`
	   html += `      <div class="score"><img src="${cpath}/resources/image/${dto.score}점.png" style="width: 100px;"></div>`
	   html += `      <div class="memo">${dto.memo}</div>`
	   html += `</div>`
	   return html   
	}

function getYMD(date) {
	   const d = new Date(date)
	   const yyyy = d.getFullYear()
	   let mm = d.getMonth() + 1
	   let dd = d.getDate()
	   if(mm < 10) {
	      mm = '0' + mm
	   }
	   if(dd < 10) {
	      dd = '0' + dd
	   }
	   return `${yyyy}-${mm}-${dd}`
	}


async function commentsLoadHandler() {
	const commentsDiv = document.getElementById('comments')
	const url = cpath + '/category/comments/' + recipeIdx
	
	await fetch(url)
	.then(resp => resp.json())
	.then(json => {
		const arrComments = json
		commentsDiv.innerHTML = ''
		arrComments.forEach(dto => {
			const html = commentsHTMLfromJSON(dto)
			commentsDiv.innerHTML += html
		})
	})
	
	const deleteBtnList = document.querySelectorAll('button.delete')
	deleteBtnList.forEach(btn => btn.onclick = deleteHandler)
	
}


function commentsWriteHandler(event) {
	event.preventDefault()
	const content = document.querySelector('#commentsWriteForm textarea')
	const content2 = document.querySelector('#commentsWriteForm select')
	const ob = {
		recipeIdx: recipeIdx,
		userIdx: loginUserIdx,
		nickName: loginNickName,
		score: content2.value,
		memo: content.value
	}
	console.log(ob)
	const url = cpath + '/category/comments/' + recipeIdx
	const opt = {
		method: 'POST',
		body: JSON.stringify(ob),
		headers: {
			'Content-Type': 'application/json; charset=utf-8'
		}
	}
	fetch(url, opt)
	.then(resp => resp.text())
	.then(text => {
		if(text == 1) {
			alert('작성성공!!')
			location.reload()
			content.value= ''
		}
	})
}

const commentsWriteForm = document.getElementById('commentsWriteForm')

document.querySelector('textarea').onfocus = function (event) {
	if(loginNickName == '') {
		const move = confirm('영상에 댓글을 쓰려면 로그인해야합니다. 로그인하시겠습니까?')
		event.target.blur()
		if(move) {
			const url = cpath + '/member/login?url=' + location.href
			location.href = url
		}
	}
}

commentsWriteForm.onsubmit = commentsWriteHandler




