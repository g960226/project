// 레시피 삭제
function deleteRecipe(event) {
	const idx = event.target.getAttribute('idx')
    const flag = confirm('정말 삭제하시겠습니까?')
    if(flag) {
       location.href = cpath + '/delete_recipe/' +  idx
    }
 }
const deleteBtnList = document.querySelectorAll('.deleteBtn')
deleteBtnList.forEach(e => e.onclick = deleteRecipe)

const td1 = document.querySelectorAll('tr > td:nth-child(1)')
const td2 = document.querySelectorAll('tr > td:nth-child(2)')
const td3 = document.querySelectorAll('tr > td:nth-child(3)')
const td4 = document.querySelectorAll('tr > td:nth-child(4)')
const td5 = document.querySelectorAll('tr > td:nth-child(5)')
const td6 = document.querySelectorAll('tr > td:nth-child(6)')
const td7 = document.querySelectorAll('tr > td:nth-child(7)')

// 레시피 상세페이지로 
function toDetailPage(event) {
	
	let recipeIdxAdmin = event.target.getAttribute('idx')
	location.href = cpath + '/category/category_detail/' + recipeIdxAdmin +'?flag=false'
}

td1.forEach(e => e.onclick = toDetailPage)
td2.forEach(e => e.onclick = toDetailPage)
td3.forEach(e => e.onclick = toDetailPage)
td4.forEach(e => e.onclick = toDetailPage)
td5.forEach(e => e.onclick = toDetailPage)
td6.forEach(e => e.onclick = toDetailPage)
td7.forEach(e => e.onclick = toDetailPage)

// 정렬
const headerList = document.querySelectorAll('.sortTable.header > th')
headerList.forEach(div => div.setAttribute('asc', 1))

function handler(event) {
	const dataList = Array.from(document.querySelectorAll('.sortTable:not(.header)'))
	const order = event.target.className
	const root = document.querySelector('tbody')
	
	
	
	const asc = +event.target.getAttribute('asc')	// 1 or -1 (이번 정렬에서 사용할 순서)
    event.target.setAttribute('asc', -asc)			// 다음 정렬을 위해 뒤집어 놓는다
	
	console.log(order)
	console.log(dataList)
	
	dataList.sort((a, b) => {
		const aa = a.querySelector('.' + order).innerText
		const bb = b.querySelector('.' + order).innerText
		
		const flag = (order == 'name') ? (aa > bb) : (+aa > +bb)
		const ret = flag ? 				1 : -1
		return ret * asc
	})
	
	dataList.forEach(data => root.appendChild(data))
}

headerList.forEach(e => e.onclick = handler)