// 회원별 댓글 삭제
function deleteComments (event) {
	const idx= event.target.getAttribute('idx')
	const flag = confirm('정말 삭제하시겠습니까?')
	if(flag) {
		location.href = cpath + '/delete_comments/' + idx
	}
}
	
const deleteBtnList = document.querySelectorAll('.deleteBtn')
deleteBtnList.forEach(e => e.onclick = deleteComments)