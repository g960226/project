// 커뮤니티 게시글 삭제
function deleteCommunity (event) {
	const idx= event.target.getAttribute('idx')
	console.log(idx)
	const flag = confirm('정말 삭제하시겠습니까?')
	if(flag) {
		location.href = cpath + '/delete_community/' + idx
	}
}	
const deleteBtnList = document.querySelectorAll('.deleteBtn')
deleteBtnList.forEach(e => e.onclick = deleteCommunity)


const td1 = document.querySelectorAll('tr > td:nth-child(1)')
const td2 = document.querySelectorAll('tr > td:nth-child(2)')
const td3 = document.querySelectorAll('tr > td:nth-child(3)')
// 댓글페이지로 이동
function toDetailPage(event) {
	const communityIdx = event.target.parentNode.getAttribute('idx')
	location.href = cpath + '/admin/community_management_comments/'+ communityIdx
}

td1.forEach(e => e.onclick = toDetailPage)
td2.forEach(e => e.onclick = toDetailPage)
td3.forEach(e => e.onclick = toDetailPage)

function getYMD(date) {
	   const d = new Date(date)
	   const yyyy = d.getFullYear()
	   let mm = d.getMonth() + 1
	   let dd = d.getDate()
	   if(mm < 10) {
	      mm = '0' + mm
	   }
	   if(dd < 10) {
	      dd = '0' + dd
	   }
	   return `${yyyy}-${mm}-${dd}`
	}