// 회원 삭제
function deleteMember (event) {
	const idx = event.target.getAttribute('idx')
    const flag = confirm('정말 삭제하시겠습니까?')
    if(flag) {
       location.href = cpath + '/delete_member/' +  idx
    }
 }
const deleteBtnList = document.querySelectorAll('.deleteBtn')
deleteBtnList.forEach(e => e.onclick = deleteMember)

const td1 = document.querySelectorAll('tr > td:nth-child(1)')
const td2 = document.querySelectorAll('tr > td:nth-child(2)')
const td3 = document.querySelectorAll('tr > td:nth-child(3)')

// 회원별 댓글 페이지로 이동
function toDetailPage(event) {
	const idx = event.target.parentNode.getAttribute('idx')
	location.href = cpath + '/admin/member_management_comments/'+idx
}

td1.forEach(e => e.onclick = toDetailPage)
td2.forEach(e => e.onclick = toDetailPage)
td3.forEach(e => e.onclick = toDetailPage)
