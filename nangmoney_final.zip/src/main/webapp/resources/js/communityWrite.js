const inputThumb = document.querySelector('input[id="thumbnailFile"]')
const thumbImagePreview = document.getElementById('thumbImagePreview')

function changeHandlerThumb(event) {
	if(event.target.files && event.target.files[0]) {
		thumbImagePreview.style.height = '200px'
	const reader = new FileReader()
	reader.onload = function(e) {
			thumbImagePreview.style.backgroundImage = 'url('+e.target.result+')'
		}
		reader.readAsDataURL(event.target.files[0])
		} else {
			thumbImagePreview.style.backgroundImage = ''
	}
}
inputThumb.onchange = changeHandlerThumb
thumbImagePreview.ondragover = () => thumbImagePreview.style.height = 0
        

const input0 = document.querySelector('input[name="myRecipeImage[0]"]')
const imagePreview0 = document.getElementById('imagePreview0')

function changeHandler0(event) {
	if(event.target.files && event.target.files[0]) {
		imagePreview0.style.height = '200px'
	const reader = new FileReader()
	reader.onload = function(e) {
		imagePreview0.style.backgroundImage = 'url('+e.target.result+')'
		}
		reader.readAsDataURL(event.target.files[0])
		} else {
		imagePreview0.style.backgroundImage = ''
	}
}
input0.onchange = changeHandler0
imagePreview0.ondragover = () => imagePreview0.style.height = 0
        

const input1 = document.querySelector('input[type="file"]')
const imagePreview = document.getElementByClassName('imagePreview')

function changeHandler1(event) {
	if(event.target.files && event.target.files[0]) {
		imagePreview.style.height = '200px'
	const reader = new FileReader()
	reader.onload = function(e) {
		imagePreview.style.backgroundImage = 'url('+e.target.result+')'
		}
		reader.readAsDataURL(event.target.files[0])
		} else {
		imagePreview.style.backgroundImage = ''
	}
}
input1.onchange = changeHandler1
imagePreview.ondragover = () => imagePreview.style.height = 0
        

// addBtn으로 추가
function removeHandler(event) {
	const target = event.target.parentNode
	files.removeChild(target)
	
	form.querySelectorAll('input[type="file"]').forEach((e, i) => e.name = 'myRecipeImage[' + i + ']')
}

function addHandler() {
	const size = document.querySelectorAll('#files input[type="file"]').length
	
	const input = document.createElement('input')
	input.type = 'file'
	input.className = 'myRecipeImageFile'
	input.name = 'myRecipeImage[' + size + ']'
	input.required = 'required'
	
	const span = document.createElement('span')
	span.className = 'remove'
	span.innerText = 'X'
	span.onclick = removeHandler
	
	const p = document.createElement('p')
	p.appendChild(input)
	p.appendChild(span)
	files.appendChild(p);
	
	const imagePreview = document.createElement('span');
	imagePreview.id = 'imagePreview' + size;
	imagePreview.className = 'imagePreview';
	imagePreview.ondragover = () => imagePreview.style.height = 0;
	p.appendChild(span)
	p.appendChild(imagePreview);

	input.onchange = function(event) {
		const imagePreview = document.getElementById('imagePreview' + size);
		if (event.target.files && event.target.files[0]) {
			imagePreview.style.height = '200px';
			const reader = new FileReader();
			reader.onload = function(e) {
				imagePreview.style.backgroundImage = 'url(' + e.target.result + ')';
			};
			reader.readAsDataURL(event.target.files[0]);
		} else {
			imagePreview.style.backgroundImage = '';
		}
	};
	const textarea = document.createElement('textarea');
	textarea.name = 'communityContent[' + size + ']';
	textarea.id = 'communityContent';
	textarea.placeholder = '당신의 비법을 알려주세요!';
	p.appendChild(textarea);
	
}
function removeHidden() {
	const addCommunitySubmit = document.getElementById('addCommunitySubmit')
	const span = document.querySelectorAll('.remove[0]')
	if(span.className == span.id) {
		addCommunitySubmit.className = 'view_submit hidden'
	}
}

function removeHandler2(event) {
	const target = event.target.parentNode
	files.removeChild(target)
	
	form.querySelectorAll('input[type="file"]').forEach((e, i) => e.name = 'myRecipeImage[' + i + ']')
}

function removeHandler3(event) {
	const target = event.target.parentNode
	const addCommunitySubmit = document.getElementById('addCommunitySubmit')
	files.removeChild(target)
	
	addCommunitySubmit.className = 'view_submit hidden'
	
	form.querySelectorAll('input[type="file"]').forEach((e, i) => e.name = 'myRecipeImage[' + i + ']')
}

function addHandler2() {
	const size = document.querySelectorAll('#files input[type="file"]').length
	const addCommunitySubmit = document.getElementById('addCommunitySubmit')
	
	addCommunitySubmit.className = 'view_submit'
	
	const input = document.createElement('input')
	input.type = 'file'
	input.className = 'myRecipeImageFile'
	input.name = 'myRecipeImage[' + size + ']'
	input.required = 'required'
	
	const span = document.createElement('span')
	span.className = 'remove'
	span.id = 'remove[' +size + ']'
	span.innerText = 'X'
	if(span.id != 'remove[0]') {
		span.onclick = removeHandler2
	}else {
		span.onclick = removeHandler3
	}
	
	const p = document.createElement('p')
	p.appendChild(input)
	p.appendChild(span)
	files.appendChild(p);
	
	const imagePreview = document.createElement('span');
	imagePreview.id = 'imagePreview' + size;
	imagePreview.className = 'imagePreview';
	imagePreview.ondragover = () => imagePreview.style.height = 0;
	p.appendChild(span)
	p.appendChild(imagePreview);

	input.onchange = function(event) {
		const imagePreview = document.getElementById('imagePreview' + size);
		if (event.target.files && event.target.files[0]) {
			imagePreview.style.height = '200px';
			const reader = new FileReader();
			reader.onload = function(e) {
				imagePreview.style.backgroundImage = 'url(' + e.target.result + ')';
			};
			reader.readAsDataURL(event.target.files[0]);
		} else {
			imagePreview.style.backgroundImage = '';
		}
	};
	const textarea = document.createElement('textarea');
	textarea.name = 'communityContent[' + size + ']';
	textarea.id = 'communityContent';
	textarea.placeholder = '당신의 비법을 알려주세요!';
	p.appendChild(textarea);
	
}
