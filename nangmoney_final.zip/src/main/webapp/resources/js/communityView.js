const commentsWriteForm = document.getElementById('commentsWriteForm')

document.querySelector('textarea').onfocus = function(event) {
	if (loginNickName == '') {
		const move = confirm('댓글을 쓰려면 로그인해야합니다. 로그인하시겠습니까?')
		event.target.blur()
		if (move) {
			const url = cpath + '/member/login?url=' + location.href
			location.href = url
		}
	}
}
document.body.onload = comuCommentsLoadHandler
commentsWriteForm.onsubmit = comuCommentsWriteHandler
