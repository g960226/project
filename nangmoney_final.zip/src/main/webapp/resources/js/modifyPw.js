	const joinSubmit = document.getElementById('joinSubmit')
	function flagModify() {
		const flag1 = sessionStorage.getItem('flag1')
		const flag2 = sessionStorage.getItem('flag2')
		if(flag1 == 1 && flag2 == 1 ) {
			joinSubmit.disabled = false
			joinSubmit.style.backgroundColor = "#FEDE29"
		} else {
			joinSubmit.disabled = true;
			joinSubmit.style.backgroundColor = "#F0F0F1"
		}
	}
  
	const passConfirm = document.querySelector('input[name=pwConfirm]')
	const password = document.getElementById('userPw')				
	const passwordConfirm = document.getElementById('pwConfirmId')	
	const confirmMsg = document.getElementById('confirmMsg')		
	const correctColor = "blue"	
	const wrongColor ="red"		

	passConfirm.onblur = function(event){
		if(!password.value) {
			confirmMsg.style.color = wrongColor
			confirmMsg.innerHTML ="비밀번호를 입력하세요"
		}
		else if(!passwordConfirm.value) {
			confirmMsg.style.color = wrongColor
			confirmMsg.innerHTML ="비밀번호 재입력을 입력하세요"
		}
		else if(password.value == passwordConfirm.value){		
			confirmMsg.style.color = correctColor	
			confirmMsg.innerHTML ="비밀번호 일치"	
			sessionStorage.setItem('flag1', 1)
			flagModify()
		}
		else{
			confirmMsg.style.color = wrongColor
			confirmMsg.innerHTML ="비밀번호 불일치"
		}
	}


// 비밀번호 유효성 체크
const chkPw = document.querySelector('input[name="userPw"]')

chkPw.onblur = function(event) {

	 const pw = $("#userPw").val()
	 const num = pw.search(/[0-9]/g)
	 const eng = pw.search(/[a-z]/ig)
	 const spe = pw.search(/[`~!@@#$%^&*|₩₩₩'₩";:₩/?]/gi)
	 

	 if(pw.length < 8 || pw.length > 20){
		confirmPw.style.color = "red"
		confirmPw.innerHTML = "8자리 ~ 20자리 이내로 입력해주세요."
	  return false
	 }else if(pw.search(/\s/) != -1){
  		confirmPw.style.color = "red"
		confirmPw.innerHTML = "비밀번호는 공백 없이 입력해주세요."
	  return false
	 }else if(num < 0 || eng < 0 || spe < 0 ){
 		confirmPw.style.color = "red"
		confirmPw.innerHTML = "영문,숫자, 특수문자를 혼합하여 입력해주세요."
	  return false
	 }else {
		confirmPw.style.color = "blue"
		confirmPw.innerHTML = "사용가능합니다"
		sessionStorage.setItem('flag2', 1)
		flagModify()
	    return true
	 }
}

