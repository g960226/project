function showPopIngChart() {
	const url = cpath + '/awardsIng1'
	fetch(url)
	.then (resp => resp.json())
	.then (json => {
		
		const arr = [
			{ingredient:json[0].ingredient1, count:json[0].countIng1},
			{ingredient:json[1].ingredient1, count:json[1].countIng1},
			{ingredient:json[2].ingredient1, count:json[2].countIng1},
			{ingredient:json[3].ingredient1, count:json[3].countIng1},
			{ingredient:json[4].ingredient1, count:json[4].countIng1}
		]
		const arr2 = [
			{ingredient:json[5].ingredient2, count:json[5].countIng2},
			{ingredient:json[6].ingredient2, count:json[6].countIng2},
			{ingredient:json[7].ingredient2, count:json[7].countIng2},
			{ingredient:json[8].ingredient2, count:json[8].countIng2},
			{ingredient:json[9].ingredient2, count:json[9].countIng2}
		]
		
		const ageArr1 = [
			{ingredient:json[10].ingredient1, count:json[10].ageCountIng1},
			{ingredient:json[11].ingredient1, count:json[11].ageCountIng1},
			{ingredient:json[12].ingredient1, count:json[12].ageCountIng1}
		]
		const ageArr2 = [
			{ingredient:json[13].ingredient1, count:json[13].ageCountIng1},
			{ingredient:json[14].ingredient1, count:json[14].ageCountIng1},
			{ingredient:json[15].ingredient1, count:json[15].ageCountIng1}
		]
		const ageArr3 = [
			{ingredient:json[16].ingredient1, count:json[16].ageCountIng1},
			{ingredient:json[17].ingredient1, count:json[17].ageCountIng1},
			{ingredient:json[18].ingredient1, count:json[18].ageCountIng1}
		]
		const ageArr4 = [
			{ingredient:json[19].ingredient1, count:json[19].ageCountIng1},
			{ingredient:json[20].ingredient1, count:json[20].ageCountIng1},
			{ingredient:json[21].ingredient1, count:json[21].ageCountIng1}
		]
		const ageArr5 = [
			{ingredient:json[22].ingredient1, count:json[22].ageCountIng1},
			{ingredient:json[23].ingredient1, count:json[23].ageCountIng1},
			{ingredient:json[24].ingredient1, count:json[24].ageCountIng1}
		]
		arr.sort((a, b) => a.count < b.count ? 1 : -1)
		arr2.sort((a, b) => a.count < b.count ? 1 : -1)
		ageArr1.sort((a, b) => a.count < b.count ? 1 : -1)
		ageArr2.sort((a, b) => a.count < b.count ? 1 : -1)
		ageArr3.sort((a, b) => a.count < b.count ? 1 : -1)
		ageArr4.sort((a, b) => a.count < b.count ? 1 : -1)
		ageArr5.sort((a, b) => a.count < b.count ? 1 : -1)
		const context = document.getElementById('popChart1')
		const context2 = document.getElementById('popChart2')
		const ageContext1 = document.getElementById('ageChart1')
		const ageContext2 = document.getElementById('ageChart2')
		const ageContext3 = document.getElementById('ageChart3')
		const ageContext4 = document.getElementById('ageChart4')
		const ageContext5 = document.getElementById('ageChart5')
 		const labels = arr.map(e => e.ingredient)
 		const labels2 = arr2.map(e => e.ingredient)
 		const ageLabels1 = ageArr1.map(e => e.ingredient)
 		const ageLabels2 = ageArr2.map(e => e.ingredient)
 		const ageLabels3 = ageArr3.map(e => e.ingredient)
 		const ageLabels4 = ageArr4.map(e => e.ingredient)
 		const ageLabels5 = ageArr5.map(e => e.ingredient)
 		// 메인재료 차트
 		const data = {
 			labels: labels,
 			datasets: [
 				{
 					label: '',
 					data: arr.map(e => e.count),
 					backgroundColor: [
 				      'rgba(255, 99, 132, 0.2)',
 				      'rgba(255, 159, 64, 0.2)',
 				      'rgba(255, 205, 86, 0.2)',
 				      'rgba(75, 192, 192, 0.2)',
 				      'rgba(54, 162, 235, 0.2)',
 				      'rgba(153, 102, 255, 0.2)',
 				      'rgba(201, 203, 207, 0.2)'
 					],
 					borderColor: [
 				      'rgb(255, 99, 132)',
 				      'rgb(255, 159, 64)',
 				      'rgb(255, 205, 86)',
 				      'rgb(75, 192, 192)',
 				      'rgb(54, 162, 235)',
 				      'rgb(153, 102, 255)',
 				      'rgb(201, 203, 207)'
 				    ],
 				    borderWidth: 1
 				}
 			]
 		}
		// 서브재료 차트
		const data2 = {
 			labels: labels2,
 			datasets: [
 				{
 					label: '',
 					data: arr2.map(e => e.count),
 					backgroundColor: [
 				      'rgba(255, 99, 132, 0.2)',
 				      'rgba(255, 159, 64, 0.2)',
 				      'rgba(255, 205, 86, 0.2)',
 				      'rgba(75, 192, 192, 0.2)',
 				      'rgba(54, 162, 235, 0.2)',
 				      'rgba(153, 102, 255, 0.2)',
 				      'rgba(201, 203, 207, 0.2)'
 					],
 					borderColor: [
 				      'rgb(255, 99, 132)',
 				      'rgb(255, 159, 64)',
 				      'rgb(255, 205, 86)',
 				      'rgb(75, 192, 192)',
 				      'rgb(54, 162, 235)',
 				      'rgb(153, 102, 255)',
 				      'rgb(201, 203, 207)'
 				    ],
 				    borderWidth: 1
 				}
 			]
 		}
 		const config = {
 			type: 'bar',
 			data: data,
 			options: {
 		        plugins: {
 		            legend: {
 		            	display: false
 		            }
 		        }
 			}
 		}
 		const popChart1 = new Chart(context, config)
		
		const config2 = {
 			type: 'bar',
 			data: data2,
 			options: {
 		        plugins: {
 		            legend: {
 		            	display: false
 		            }
 		        }
 		    }
 		}
 		const popChart2 = new Chart(context2, config2)
		
		// 10대
		const ageData1 = {
 			labels: ageLabels1,
 			datasets: [
 				{
 					label: '',
 					data: ageArr1.map(e => e.count),
 					backgroundColor: [
 						  'rgba(254, 67, 101, 0.2)',
 						  'rgba(255, 159, 64, 0.2)',
 	 				      'rgba(255, 205, 86, 0.2)',
 	 				      'rgba(75, 192, 192, 0.2)',
 	 				      'rgba(54, 162, 235, 0.2)',
 	 				      'rgba(153, 102, 255, 0.2)',
 	 				      'rgba(201, 203, 207, 0.2)'
 					],
 					borderColor: [
 	 					  'rgb(254, 67, 101)',
 	 				      'rgb(255, 159, 64)',
 	 				      'rgb(255, 205, 86)',
 	 				      'rgb(75, 192, 192)',
 	 				      'rgb(54, 162, 235)',
 	 				      'rgb(153, 102, 255)',
 	 				      'rgb(201, 203, 207)'
 				    ],
 				    borderWidth: 1
 				}
 			]
 		}
 		const ageConfig1 = {
 			type: 'doughnut',
 			data: ageData1,
 			options: {
 				hoverOffset: 30,
 				layout:{
 					padding: 15
 				}
 			}
 		}
 		const ageChart1 = new Chart(ageContext1, ageConfig1)
		
		// 20대
		const ageData2 = {
 			labels: ageLabels2,
 			datasets: [
 				{
 					label: '',
 					data: ageArr2.map(e => e.count),
 					backgroundColor: [
					  'rgba(254, 67, 101, 0.2)',
					  'rgba(255, 159, 64, 0.2)',
 				      'rgba(255, 205, 86, 0.2)',
 				      'rgba(75, 192, 192, 0.2)',
 				      'rgba(54, 162, 235, 0.2)',
 				      'rgba(153, 102, 255, 0.2)',
 				      'rgba(201, 203, 207, 0.2)'
 					],
 					borderColor: [
 					  'rgb(254, 67, 101)',
 				      'rgb(255, 159, 64)',
 				      'rgb(255, 205, 86)',
 				      'rgb(75, 192, 192)',
 				      'rgb(54, 162, 235)',
 				      'rgb(153, 102, 255)',
 				      'rgb(201, 203, 207)'
 				    ],
 				    borderWidth: 1
 				}
 			]
 		}
 		const ageConfig2 = {
 			type: 'doughnut',
 			data: ageData2,
 			options: {
 				hoverOffset: 30,
 				layout:{
 					padding: 15
 				}
 			}
 		}
 		const ageChart2 = new Chart(ageContext2, ageConfig2)
		
		// 30대
		const ageData3 = {
 			labels: ageLabels3,
 			datasets: [
 				{
 					label: '',
 					data: ageArr3.map(e => e.count),
 					backgroundColor: [
 						  'rgba(254, 67, 101, 0.2)',
 						  'rgba(255, 159, 64, 0.2)',
 	 				      'rgba(255, 205, 86, 0.2)',
 	 				      'rgba(75, 192, 192, 0.2)',
 	 				      'rgba(54, 162, 235, 0.2)',
 	 				      'rgba(153, 102, 255, 0.2)',
 	 				      'rgba(201, 203, 207, 0.2)'
 	 					],
 	 					borderColor: [
 	 					  'rgb(254, 67, 101)',
 	 				      'rgb(255, 159, 64)',
 	 				      'rgb(255, 205, 86)',
 	 				      'rgb(75, 192, 192)',
 	 				      'rgb(54, 162, 235)',
 	 				      'rgb(153, 102, 255)',
 	 				      'rgb(201, 203, 207)'
 	 				    ],
 	 				    borderWidth: 1
 				}
 			]
 		}
 		const ageConfig3 = {
 			type: 'doughnut',
 			data: ageData3,
 			options: {
 				hoverOffset: 30,
 				layout:{
 					padding: 15
 				}
 			}
 		}
 		const ageChart3 = new Chart(ageContext3, ageConfig3)
		
		// 40대
		const ageData4 = {
 			labels: ageLabels4,
 			datasets: [
 				{
 					label: '',
 					data: ageArr4.map(e => e.count),
 					backgroundColor: [
 						  'rgba(254, 67, 101, 0.2)',
 						  'rgba(255, 159, 64, 0.2)',
 	 				      'rgba(255, 205, 86, 0.2)',
 	 				      'rgba(75, 192, 192, 0.2)',
 	 				      'rgba(54, 162, 235, 0.2)',
 	 				      'rgba(153, 102, 255, 0.2)',
 	 				      'rgba(201, 203, 207, 0.2)'
 	 					],
 	 					borderColor: [
 	 					  'rgb(254, 67, 101)',
 	 				      'rgb(255, 159, 64)',
 	 				      'rgb(255, 205, 86)',
 	 				      'rgb(75, 192, 192)',
 	 				      'rgb(54, 162, 235)',
 	 				      'rgb(153, 102, 255)',
 	 				      'rgb(201, 203, 207)'
 	 				    ],
 	 				    borderWidth: 1
 				}
 			]
 		}
 		const ageConfig4 = {
 			type: 'doughnut',
 			data: ageData4,
 			options: {
 				hoverOffset: 30,
 				layout:{
 					padding: 15
 				}
 			}
 		}
 		const ageChart4 = new Chart(ageContext4, ageConfig4)
		
		// 50대
		const ageData5 = {
 			labels: ageLabels5,
 			datasets: [
 				{
 					label: '',
 					data: ageArr5.map(e => e.count),
 					backgroundColor: [
 						  'rgba(254, 67, 101, 0.2)',
 						  'rgba(255, 159, 64, 0.2)',
 	 				      'rgba(255, 205, 86, 0.2)',
 	 				      'rgba(75, 192, 192, 0.2)',
 	 				      'rgba(54, 162, 235, 0.2)',
 	 				      'rgba(153, 102, 255, 0.2)',
 	 				      'rgba(201, 203, 207, 0.2)'
 	 					],
 	 					borderColor: [
 	 					  'rgb(254, 67, 101)',
 	 				      'rgb(255, 159, 64)',
 	 				      'rgb(255, 205, 86)',
 	 				      'rgb(75, 192, 192)',
 	 				      'rgb(54, 162, 235)',
 	 				      'rgb(153, 102, 255)',
 	 				      'rgb(201, 203, 207)'
 	 				    ],
 	 				    borderWidth: 1
 				}
 			]
 		}
 		const ageConfig5 = {
 			type: 'doughnut',
 			data: ageData5,
 			options: {
 				hoverOffset: 30,
 				layout:{
 					padding: 15
 				}
 			}
 		}
 		const ageChart5 = new Chart(ageContext5, ageConfig5)
	})		
}