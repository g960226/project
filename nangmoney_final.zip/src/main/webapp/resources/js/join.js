	// 회원가입 유효성 체크를 하기 전 버튼 비활성화
const joinSubmit = document.getElementById('joinSubmit')
function flagModify() {
	const flag1 = sessionStorage.getItem('flag1')
	const flag2 = sessionStorage.getItem('flag2')
	const flag3 = sessionStorage.getItem('flag3')
	const flag4 = sessionStorage.getItem('flag4')
	const flag5 = sessionStorage.getItem('flag5')
	const flag6 = sessionStorage.getItem('flag6')
	if(flag1 == 1 && flag2 == 1 && flag3 == 1 && flag4 == 1 && flag5 == 1 && flag6 == 1) {
		joinSubmit.disabled = false
		joinSubmit.style.backgroundColor = "#FEDE29"
	} else {
		joinSubmit.disabled = true;
		joinSubmit.style.backgroundColor = "#F0F0F1"
	}
}

/* 비밀번호, 비밀번호 확인 입력창에 입력된 값을 비교해서 같다면 비밀번호 일치, 그렇지 않으면 불일치 라는 텍스트 출력.*/
	const passConfirm = document.querySelector('input[name=pwConfirm]')
	const password = document.getElementById('userPw')				//비밀번호 
	const passwordConfirm = document.getElementById('pwConfirm')	//비밀번호 확인 값
	const confrimMsg = document.getElementById('confirmMsg')		//확인 메세지
	const correctColor = "blue"	//맞았을 때 출력되는 색깔
	const wrongColor ="red"		//틀렸을 때 출력되는 색깔
	
	passConfirm.onblur = function(event){
		if(!pwConfirm.value) {
			confirmMsg.style.color = wrongColor
			confirmMsg.innerHTML ="비밀번호를 입력하세요"
			sessionStorage.removeItem('flag1')
			flagModify()
		}
		else if(!pwConfirm.value) {
			confirmMsg.style.color = wrongColor
			confirmMsg.innerHTML ="비밀번호 재입력을 입력하세요"
			sessionStorage.removeItem('flag1')
			flagModify()
		}
		else if(password.value == pwConfirm.value){		//password 변수의 값과 pwConfirm 변수의 값과 동일하다.
			confirmMsg.style.color = correctColor	/* span 태그의 ID(confirmMsg) 사용  */
			confirmMsg.innerHTML ="비밀번호 일치"		/* innerHTML : HTML 내부에 추가적인 내용을 넣을 때 사용하는 것. */
			sessionStorage.setItem('flag1', 1)
			flagModify()
		}
		else{
			confirmMsg.style.color = wrongColor
			confirmMsg.innerHTML ="비밀번호 불일치"
			sessionStorage.removeItem('flag1')
			flagModify()
		}
	}

	// 이메일 중복체크
	const dupCheck = document.querySelector('input[name="userEmail"]')
	const dupResult = document.querySelector('span.dupResult')
	const regExp = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i
	
	dupCheck.onblur = function(event) {
		const inputId = dupCheck.value
		const emailRegex = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
		if(!inputId){
			dupResult.innerText = '이메일을 입력하세요'
			dupResult.style.color = 'red'
			email_auth.disabled = true;
			email_auth.style.backgroundColor = "#F0F0F1"
			sessionStorage.removeItem('flag2')
			flagModify()
		    return false
		} else if(!emailRegex.test(inputId)) {
			dupResult.innerText = '이메일형식으로 입력하세요'
			dupResult.style.color = 'red'
			email_auth.disabled = true;
			email_auth.style.backgroundColor = "#F0F0F1"
			sessionStorage.removeItem('flag2')
			flagModify()
			return false
		}
		const url = cpath + '/dupCheck/' + inputId +'/'
		
		console.log(url)
		
		fetch(url)						
		.then(resp => resp.text())		
		.then(text => {					
			const code = text.split(':')[0]		// 1 : 사용중, 0 : 중복없음	
			const result = text.split(':')[1]
			dupResult.innerText = result
			dupResult.style.color = code == 1 ? 'red' : 'blue'
				if(code == 0) {
					email_auth.disabled = false
					email_auth.style.backgroundColor = "#FEDE29"
					sessionStorage.setItem('flag2', 1)
					flagModify()
			} else {
				email_auth.disabled = true;
				email_auth.style.backgroundColor = "#F0F0F1"
				sessionStorage.removeItem('flag2')
				flagModify()
			}
		})
	}

	// 닉네임 중복체크
	const nicknameCheck = document.querySelector('input[name="nickName"]')
	const nicknameDupResult = document.querySelector('span.nicknameDupResult')
	
	nicknameCheck.onblur = function(event) {
		const inputNickName = document.querySelector('input[name="nickName"]').value
		if(!inputNickName){
			nicknameDupResult.innerText = '닉네임을 입력하세요'
			nicknameDupResult.style.color = 'red'
		    return false;
		} 
		const url = cpath + '/nicknameDupResult/' + inputNickName
		
		console.log(url)
		
		fetch(url)						
		.then(resp => resp.text())		
		.then(text => {					
			const code = text.split(':')[0]		// 1 : 사용중, 0 : 중복없음	
			const result = text.split(':')[1]
			nicknameDupResult.innerText = result
			nicknameDupResult.style.color = code == 1 ? 'red' : 'blue'
			if(code == 0) {
				sessionStorage.setItem('flag3', 1)
				flagModify()
			} else {
				sessionStorage.removeItem('flag3')
				flagModify()
			}
		})
	}

// 비밀번호 유효성 체크
const chkPw = document.querySelector('input[name="userPw"]')

chkPw.onblur = function(event) {

	 const pw = $("#userPw").val()
	 const num = pw.search(/[0-9]/g)
	 const eng = pw.search(/[a-z]/ig)
	 const spe = pw.search(/[`~!@@#$%^&*|₩₩₩'₩";:₩/?]/gi)

	 if(pw.length < 8 || pw.length > 20){
		confirmPw.style.color = "red"
		confirmPw.innerHTML = "8자리 ~ 20자리 이내로 입력해주세요."
		sessionStorage.removeItem('flag4')
		flagModify()
	  return false
	 }else if(pw.search(/\s/) != -1){
  		confirmPw.style.color = "red"
		confirmPw.innerHTML = "비밀번호는 공백 없이 입력해주세요."
		sessionStorage.removeItem('flag4')
		flagModify()
	  return false
	 }else if(num < 0 || eng < 0 || spe < 0 ){
 		confirmPw.style.color = "red"
		confirmPw.innerHTML = "영문,숫자, 특수문자를 혼합하여 입력해주세요."
		sessionStorage.removeItem('flag4')
		flagModify()
	  return false
	 }else {
		confirmPw.style.color = "blue"
		confirmPw.innerHTML = "사용가능합니다"
		sessionStorage.setItem('flag4', 1)
		flagModify()
	    return true
	 }
}

	const email_auth = document.querySelector('input[name="email_auth"]')
	
	email_auth.onclick = function(event) {
		const inputEmail = dupCheck.value
		const url = cpath + '/email_auth/' + inputEmail + '/'
				
		fetch(url)
		.then(resp => resp.text())
		.then(text => {
			if(text == 1) {
				// 여기에 팝업창을 띄우거나 밑에 classList에 hidden을 제거하거나 하면됩니다. 저는 hidden으로 처리할께요
				alert('인증번호가 발송되었습니다. 메일을 확인해주세요')
				sessionStorage.setItem('flag5', 1)
				email_check.disabled = false
				email_check.style.backgroundColor = "#FEDE29"
				flagModify()
			}else {
				sessionStorage.removeItem('flag5')
				flagModify()
			}
		})
		.catch(ex => {
			console.log(ex)
		})
	}

	const email_check = document.querySelector('input[name="email_check"]')
	
	email_check.onclick = function(event) {
		const ob = {
				email : dupCheck.value,
				authNumber : document.querySelector('input[name="authNumber"]').value,
		}
		
		const url = cpath + '/sendAuthNumber'
		const opt = {
				method: 'POST',
				body: JSON.stringify(ob),
				headers: {
					'Content-Type': 'application/json; charset=utf-8'
				} 
		}
		fetch(url, opt)
		.then(resp => resp.text())
		.then(text => {
			console.log(text) 
			const flag = (text == 1) ? 'true' : 'false'
			if(text == 1) {
				alert('인증이 완료되었습니다')
				sessionStorage.setItem('flag6', 1)
				flagModify()
			}
			else {
				alert('인증번호가 일치하지 않습니다. 다시 확인해주세요')
				sessionStorage.removeItem('flag6')
				flagModify()
			}
		})
	}
		
	
	
	
	