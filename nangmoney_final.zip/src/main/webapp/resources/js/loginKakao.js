$(document).ready(function(){
  Kakao.init('5183de1f0e35ca0d03af6492e4c6c2ff') // 사용하려는 앱의 JavaScript 키 입력
  Kakao.isInitialized()
})

function loginWithKakao() {
  Kakao.Auth.login({
        success: function(authObj) {
         
          //2. 로그인 성공시, API 호출
          Kakao.API.request({
            url: '/v2/user/me',
            success: function(res) {
              const email = res.kakao_account.email
              const userPw = res.id
              const age = res.kakao_account.age_range
              const nickNames = res.properties.nickname
              	const ob = {
            	  			userEmail : email,
            	  			userPw : userPw,
            	  			age : age,
            	  			userName : nickNames,
            	  			nickName : nickNames,
            	  			userGroups : 2
						}
          	const url = cpath + '/member/kakao/callback'
        	const opt = {
        		method: 'POST',
        		body: JSON.stringify(ob),
        		headers: {
        			'Content-Type': 'application/json; charset=utf-8'
        		}
        	}
        	fetch(url, opt)
        	.then(resp => resp.text())
        	.then(text => {
        		if(text == 1) {
        			  window.location.href = cpath +'/';
        		} else {
        			window.location.href = cpath + '/member/joinKakao?userEmail=' + email +'&userPw=' + userPw
        					+ '&age=' + age +'&userName=' + nickNames +'&nickName=' + nickNames
        		}
        	})
              
        }
          })
        },
        fail: function(err) {
          alert(JSON.stringify(err))
        }
      })
  }
