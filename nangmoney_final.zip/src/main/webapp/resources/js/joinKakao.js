
// 회원가입 유효성 체크를 하기 전 버튼 비활성화
const joinSubmit = document.getElementById('joinSubmit')
function flagModify() {
	const flag3 = sessionStorage.getItem('flag3')
	if(flag3 == 1) {
		joinSubmit.disabled = false
		joinSubmit.style.backgroundColor = "#FEDE29"
	} else {
		joinSubmit.disabled = true;
		joinSubmit.style.backgroundColor = "#F0F0F1"
	}
}



	// 닉네임 중복체크
	const nicknameCheck = document.querySelector('input[name="nickName"]')
	const nicknameDupResult = document.querySelector('span.nicknameDupResult')
	
	nicknameCheck.onblur = function(event) {
		const inputNickName = document.querySelector('input[name="nickName"]').value
		if(!inputNickName){
			nicknameDupResult.innerText = '닉네임을 입력하세요'
			nicknameDupResult.style.color = 'red'
		    return false;
		} 
		const url = cpath + '/nicknameDupResult/' + inputNickName
		
		console.log(url)
		
		fetch(url)						
		.then(resp => resp.text())		
		.then(text => {					
			const code = text.split(':')[0]		// 1 : 사용중, 0 : 중복없음	
			const result = text.split(':')[1]
			nicknameDupResult.innerText = result
			nicknameDupResult.style.color = code == 1 ? 'red' : 'blue'
			if(code == 0) {
				sessionStorage.setItem('flag3', 1)
				flagModify()
			}
		})
	}

