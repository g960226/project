      const body = document.querySelector('body')
      const modal = document.querySelector('.modal')
      const btnOpenPopup = document.querySelector('.btn-open-popup')

      btnOpenPopup.addEventListener('click', () => {
        modal.classList.toggle('show')

        if (modal.classList.contains('show')) {
          body.style.overflow = 'hidden'
        }
      })

      modal.addEventListener('click', (event) => {
        if (event.target === modal) {
          modal.classList.toggle('show')

          if (!modal.classList.contains('show')) {
            body.style.overflow = 'auto'
          }
        }
      })
    
	const dupCheck = document.querySelector('input[name="userEmailFind"]')
	const findResult = document.querySelector('span.findResult')
	const regExp = /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i
	
	dupCheck.onblur = function(event) {
		const inputId = dupCheck.value
		const emailRegex = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
		if(!inputId){
			findResult.innerText = '이메일을 입력하세요'
			findResult.style.color = 'red'
			email_find.disabled = true;
			email_find.style.backgroundColor = "#F0F0F1"
		    return false
		} else if(!emailRegex.test(inputId)) {
			findResult.innerText = '이메일형식으로 입력하세요'
			findResult.style.color = 'red'
			email_find.disabled = true;
			email_find.style.backgroundColor = "#F0F0F1"
			return false
		}
		const url = cpath + '/dupCheckFind/' + inputId +'/'
		
		
		fetch(url)						
		.then(resp => resp.text())		
		.then(text => {					
			const code = text.split(':')[0]		// 1 : 사용중, 0 : 중복없음	
			const result = text.split(':')[1]
			findResult.innerText = result
			findResult.style.color = code == 1 ? 'blue' : 'red'
			if(code == 1) {
				email_find.disabled = false;
				email_find.style.backgroundColor = "#FEDE29"
			} else {
				email_find.disabled = true;
				email_find.style.backgroundColor = "#F0F0F1"
			}
		})
	}
    
	const email_find = document.querySelector('input[name="email_find"]')

		email_find.onclick = function(event) {
			const inputEmail = dupCheck.value
			const url = cpath + '/email_find/' + inputEmail + '/'
					
			fetch(url)
			.then(resp => resp.text())
			.then(text => {
				if(text == 1) {
					alert('임시비밀번호가 발송되었습니다. 메일을 확인해주세요')
				}
			})
			.catch(ex => {
				console.log(ex)
			})
		}
	
