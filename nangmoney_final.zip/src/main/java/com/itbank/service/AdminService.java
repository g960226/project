package com.itbank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.model.CategoryDTO;
import com.itbank.model.CommentsDTO;
import com.itbank.model.CommunityDTO;
import com.itbank.model.MemberDTO;
import com.itbank.model.RecipeDTO;
import com.itbank.repository.CommentsDAO;
import com.itbank.repository.CommunityDAO;
import com.itbank.repository.ComuCommentsDAO;
import com.itbank.repository.MemberDAO;
import com.itbank.repository.RecipeDAO;

@Service
public class AdminService {
	
	@Autowired MemberDAO memberDao;
	@Autowired RecipeDAO recipeDao;
	@Autowired CommentsDAO commentsDao;
	@Autowired CommunityDAO communityDao;
	@Autowired ComuCommentsDAO comucommentsDao;
	
	public List<MemberDTO> getList_member() {
		return memberDao.selectList_member();
	}

	public int delete_member(int userIdx) {
		return memberDao.delete_member(userIdx);
	}

	public List<RecipeDTO> getList_recipe() {
		return recipeDao.selectList_video();
	}

	public List<MemberDTO> getSearchList(String userName) {
		return memberDao.getSearchMember(userName);
	}

	public int delete_recipe(int recipeIdx) {
		return recipeDao.delete_recipe(recipeIdx);
	}

	public RecipeDTO getRecipeDTO(int recipeIdx) {
		
		return recipeDao.selectOne_recipe(recipeIdx);
	}

	public List<RecipeDTO> getSearchRecipeList(String recipeName) {
		return recipeDao.getSearchRecipe(recipeName);
	}

	public List<CommentsDTO> getUserCommentsList(int userIdx) {
		return commentsDao.selectUserCommentsList(userIdx);
	}
	
	public int delete_comments(int commentsIdx) {
		return commentsDao.delete_comments(commentsIdx);
	}

	public List<CategoryDTO> getSearchCategoryList() {
		return recipeDao.getSearchCategory();
	}

	public List<CommunityDTO> getList_commnuity() {
		return communityDao.selectList_community() ;
	}

	public int delete_Comcomments(int comucommentsIdx) {
		return comucommentsDao.delete_comments(comucommentsIdx);
	}

	

	}


