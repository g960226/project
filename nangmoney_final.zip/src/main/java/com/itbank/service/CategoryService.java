package com.itbank.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.model.CategoryDTO;
import com.itbank.model.RecipeDTO;
import com.itbank.repository.CommentsDAO;
import com.itbank.repository.RecipeDAO;

@Service
public class CategoryService {

	@Autowired private RecipeDAO recipeDao;
	@Autowired private CommentsDAO commentsDao;

	public List<RecipeDTO> getRecipeList() {
		return recipeDao.getRecipeList();
	}

	public List<RecipeDTO> selectIngredient(CategoryDTO dto) {
		return recipeDao.selectIngredient(dto);
	}

	public RecipeDTO getRecipeDTO(int recipeIdx, int userIdx) {
		recipeDao.updateViews(recipeIdx);
		setScore(recipeIdx);
		RecipeDTO dto = recipeDao.selectOne_recipe(recipeIdx);
		int row = 0;
		Integer row2 = recipeDao.heartCheckRecipe(recipeIdx, userIdx);
		if(row2 == null) {
			row = 0;
		}else {
			row = row2;
		}
		dto.setHeartCheck(row);
		return dto;
	}
	
	public void setScore(int recipeIdx) {
		
		Double scoreAvg = commentsDao.getScoreAvg(recipeIdx);
		int scoreUserSum = commentsDao.getUserSum(recipeIdx);
		
		if(scoreAvg == null) {
			scoreAvg = 0.0;
		}
		
		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("scoreAvg", scoreAvg);
		param.put("recipeIdx", recipeIdx);
		
		commentsDao.updateScoreAvg(param);
		
		HashMap<String, Object> param2 = new HashMap<String, Object>();
		param2.put("scoreUserSum", scoreUserSum);
		param2.put("recipeIdx", recipeIdx);
		
		commentsDao.updateUserSum(param2);
	}

	public RecipeDTO getRecipeDTO(int recipeIdx) {
		return recipeDao.selectOne_recipe(recipeIdx);
	}


}
