package com.itbank.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.model.CommentsDTO;
import com.itbank.repository.CommentsDAO;

@Service
public class CommentsService {

	@Autowired CommentsDAO commentsDao;
	
	public List<CommentsDTO> commentsList(int recipeIdx) {
		return commentsDao.getCommentsList(recipeIdx);
	}

	public int writeComments(CommentsDTO dto) {
		int row = commentsDao.writeComments(dto);
		return row;
	}

	public int delete(int commentsIdx) {
		int recipeIdx = commentsDao.getRecipeIdx(commentsIdx);
		setScore(recipeIdx);
		return commentsDao.delete_comments(commentsIdx);
	}

	public CommentsDTO commentsSelectOne(int commentsIdx) {
		return commentsDao.commentsSelectOne(commentsIdx);
	}

	public void setScore(int recipeIdx) {
		
		Double scoreAvg = commentsDao.getScoreAvg(recipeIdx);
		int scoreUserSum = commentsDao.getUserSum(recipeIdx);
		
		if(scoreAvg == null) {
			scoreAvg = 0.0;
		}
		
		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("scoreAvg", scoreAvg);
		param.put("recipeIdx", recipeIdx);
		
		commentsDao.updateScoreAvg(param);
		
		HashMap<String, Object> param2 = new HashMap<String, Object>();
		param2.put("scoreUserSum", scoreUserSum);
		param2.put("recipeIdx", recipeIdx);
		
		commentsDao.updateUserSum(param2);
	}
	


}
