package com.itbank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.repository.HeartDAO;
import com.itbank.repository.RecipeDAO;

@Service
public class HeartService {

	@Autowired HeartDAO heartDao;
	@Autowired RecipeDAO recipeDao;
	
	public int insertHeart(int recipeIdx, int userIdx) {
		recipeDao.updateHeart(recipeIdx);
		int row = heartDao.insertHeart(recipeIdx, userIdx);
		return row;
	}

	public int deleteHeart(int recipeIdx, int userIdx) {
		recipeDao.updateMinusHeart(recipeIdx);
		int row = heartDao.deleteHeart(recipeIdx, userIdx);
		return row;
	}

}
