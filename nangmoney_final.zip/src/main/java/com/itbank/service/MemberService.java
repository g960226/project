package com.itbank.service;

import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import com.itbank.component.HashComponent;
import com.itbank.model.MemberDTO;
import com.itbank.repository.MemberDAO;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.AddressException;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

@Service
public class MemberService {
	
	@Autowired private MemberDAO memberDao;
	@Autowired private HashComponent hashComponent;
	
	@Value("classpath:account.txt")
	private Resource account;

	public void add(MemberDTO dto) {
		memberDao.addMember(dto);
	}

	public int dupCheck(String inputId) {
		return memberDao.dupCheck(inputId);
	}

	public int nickNameDupCheck(String inputNickName) {
		return memberDao.nicknameDupResult(inputNickName);
	}

	public MemberDTO login(MemberDTO dto) {
		return memberDao.login(dto);
	}

	public int sendMail(String inputEmail, String authNumber) throws IOException {
		
		Scanner sc = new Scanner(account.getFile());
		String accoutInfo = null;
		while(sc.hasNextLine()) {
			accoutInfo = sc.nextLine();
		}
		sc.close();
		
		String host = "smtp.naver.com";
		int port = 465;
		final String serverId = accoutInfo.split("/")[0];
		final String serverPw = accoutInfo.split("/")[1];
		
		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", port);
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.ssl.enable", "true");
		props.put("mail.smtp.ssl.trust", host);
		
		Session mailSession = Session.getDefaultInstance(props, new Authenticator() {
			String un = serverId;
			String pw = serverPw;
			
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(un, pw);
			}
		});
		mailSession.setDebug(true);
		
		Message mimeMessage = new MimeMessage(mailSession);
		
		String body = "";
		body += "<div style=\"padding: 10px; border:3px solid #dadada;\">";
		body += "	<h3>인증번호</h3>";
		body += "	<p>인증번호는 <b>[%s]</b>입니다";
		body += "</div>";
		
		try {
			mimeMessage.setFrom(new InternetAddress("hwo7513565@naver.com"));
			mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(inputEmail));
			mimeMessage.setSubject("[냉머니] 인증번호입니다");
			body = String.format(body, authNumber);
			mimeMessage.setContent(body, "text/html; charset=utf-8");	
			Transport.send(mimeMessage);
			return 1;
		} catch (AddressException e) {
			e.printStackTrace();
			System.out.println("잘못된 주소입니다");
			return -1;
		} catch (MessagingException e) {
			e.printStackTrace();
			System.out.println("메시지 전송에 문제가 발생했습니다");
			return -2;
		}
	}
	
	public MemberDTO getMypage(int userIdx) {
		return memberDao.getMypage(userIdx);
	}

	public int modifyMypage(MemberDTO dto) {
		return memberDao.modifyMypage(dto);
	}

	public void modifyPw(MemberDTO dto) {
		memberDao.modifyPw(dto);
		
	}

	public int withdraw_member(int userIdx) {
		return memberDao.withdraw_member(userIdx);
	}

	public void findSetPw(String userEmail, String userPw) {
		userPw = hashComponent.getHash(userPw);
		memberDao.findSetPw(userEmail, userPw);
	}

	public int sendMailsetPw(String inputEmail, String authString) throws IOException {
		
		Scanner sc = new Scanner(account.getFile());
		String accoutInfo = null;
		while(sc.hasNextLine()) {
			accoutInfo = sc.nextLine();
		}
		sc.close();
		
		String host = "smtp.naver.com";
		int port = 465;
		final String serverId = accoutInfo.split("/")[0];
		final String serverPw = accoutInfo.split("/")[1];
		
		Properties props = new Properties();
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", port);
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.ssl.enable", "true");
		props.put("mail.smtp.ssl.trust", host);
		
		Session mailSession = Session.getDefaultInstance(props, new Authenticator() {
			String un = serverId;
			String pw = serverPw;
			
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(un, pw);
			}
		});
		mailSession.setDebug(true);
		
		Message mimeMessage = new MimeMessage(mailSession);
		
		String body = "";
		body += "<div style=\"padding: 10px; border:3px solid #dadada;\">";
		body += "	<h3>임시비밀번호</h3>";
		body += "	<p>임시비밀번호는 <b>[%s]</b>입니다";
		body += "	<p>로그인 후 비밀번호를 변경해주세요";
		body += "</div>";
		
		try {
			mimeMessage.setFrom(new InternetAddress("hwo7513565@naver.com"));
			mimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(inputEmail));
			mimeMessage.setSubject("[냉머니] 임시비밀번호입니다");
			body = String.format(body, authString);
			mimeMessage.setContent(body, "text/html; charset=utf-8");	
			Transport.send(mimeMessage);
			return 1;
		} catch (AddressException e) {
			e.printStackTrace();
			System.out.println("잘못된 주소입니다");
			return -1;
		} catch (MessagingException e) {
			e.printStackTrace();
			System.out.println("메시지 전송에 문제가 발생했습니다");
			return -2;
		}
	}

	public MemberDTO loginKakao(MemberDTO dto) {
		return memberDao.loginKakao(dto);
	}

	public int showMypage(MemberDTO dto) {
		return memberDao.showMypage(dto);
	}


	

}
