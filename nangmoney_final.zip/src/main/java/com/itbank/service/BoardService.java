package com.itbank.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.model.AwardDTO;
import com.itbank.model.Paging;
import com.itbank.model.RecipeDTO;
import com.itbank.repository.BoardDAO;

@Service
public class BoardService {

	@Autowired private BoardDAO dao;


	public List<RecipeDTO> getList() {
		return dao.selectListAll();
	}
	
	public List<RecipeDTO> getNewrecipe() {
		return dao.selectNewrecipe();
	}
	
	
	public int getBoardSearchCount(String recipeName) {
		return dao.selectSearchBoardCount(recipeName);
	}

	public List<RecipeDTO> search(String recipeName, Paging paging) {
		HashMap<String, Object> param = new HashMap<String, Object>();
	    param.put("offset", paging.getOffset());
	    param.put("perPage", paging.getPerPage());
	    param.put("recipeName",recipeName);
	    
	    return dao.search(param);
	}

	public int getBoardCount() {
		return dao.selectBoardCount();
	}

	public List<RecipeDTO> getListAll(Paging paging) {
		HashMap<String, Object> param = new HashMap<String, Object>();
	    param.put("offset", paging.getOffset());
	    param.put("perPage", paging.getPerPage());
		
		return dao.selectAll(param);
	}

	public List<AwardDTO> getPopularAwardIng1() {
		List<AwardDTO> dto = dao.getPopularAwardIng1();
		dto.addAll(dao.getPopularAwardIng2());
		dto.addAll(dao.getAge10Chart());
		dto.addAll(dao.getAgeTwoChart());
		dto.addAll(dao.getAgeThreeChart());
		dto.addAll(dao.getAgeForeChart());
		dto.addAll(dao.getAgeFiveChart());
		return dto;
	}

	public List<RecipeDTO> getPopularScore() {
		return dao.getPopularScore();
	}

	public List<RecipeDTO> getPopularLikeSum() {
		return dao.getPopularLikeSum();
	}
	
}
