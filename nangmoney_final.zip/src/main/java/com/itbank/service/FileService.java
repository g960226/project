package com.itbank.service;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.itbank.model.RecipeDTO;
import com.itbank.repository.RecipeDAO;

@Service
public class FileService {

	@Autowired
	private RecipeDAO dao;

	   String linuxPath = "/nangmoney_t_img";
	   String windowsPath = "C:\\nangmoney_t_img";
	   
	   String sep = File.separator;
	   private final String saveDirectory = "\\".equals(sep) ? windowsPath : linuxPath;
	
	   public FileService() {
	      File dir = new File(saveDirectory);
	      if (dir.exists() == false) {
	         dir.mkdirs();
	      }
	   }

	// 레시피 업로드
	public int uploadRecipe(RecipeDTO dto) {
		// 영상제목.(확장자명)
		String fileName = dto.getRecipeName() + "." + dto.getUploadThumbNail().getContentType().split("/")[1];
		File dest = new File(saveDirectory, fileName);
		try {
			dto.getUploadThumbNail().transferTo(dest);
			dto.setRecipeThumbNail(fileName);
			int row = dao.insert_recipe(dto);
			int idx = -1;
			if(row == 1) {
				idx = dao.selectRecentRecipeIdx();
			}
			return idx;

		} catch (IllegalStateException | IOException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int modifyRecipe(RecipeDTO dto) {
		MultipartFile thumbnailFile = dto.getUploadThumbNail();
 		String fileName = dto.getRecipeName() + "." + dto.getRecipeThumbNail().split("[.]")[1];
		
		if (thumbnailFile.getSize() != 0) {
			File oldFile = new File(saveDirectory, dto.getRecipeThumbNail());
			if (oldFile.exists()) {
				oldFile.delete();
			}
			fileName = dto.getRecipeName() + "." + dto.getUploadThumbNail().getContentType().split("/")[1];
			File dest = new File(saveDirectory, fileName);
			try {
				dto.getUploadThumbNail().transferTo(dest);
				dto.setRecipeThumbNail(fileName);
				int row = dao.update_recipe(dto);
				return row;
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		}
		if(!fileName.equals(dto.getRecipeThumbNail())) {
			File file1 = new File(saveDirectory, dto.getRecipeThumbNail());
			File file2 = new File(saveDirectory, fileName);
			file1.renameTo(file2);
		}
		dto.setRecipeThumbNail(fileName);
		return dao.update_recipe(dto);
	}

	// 파일 삭제
	public void deleteFile(String recipeThumbNail) {
		File f = new File(saveDirectory, recipeThumbNail);
		if(f.exists()) {
			f.delete();
		}
	}

	
	}
 
