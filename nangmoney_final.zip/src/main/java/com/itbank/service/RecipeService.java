package com.itbank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.model.CategoryDTO;
import com.itbank.model.RecipeDTO;
import com.itbank.repository.RecipeDAO;
@Service
public class RecipeService {
	
	@Autowired
	private RecipeDAO dao;

	public List<RecipeDTO> getList() {
		return dao.getList();
	}

	public List<RecipeDTO> getPopList() {
		return dao.getPopList();
	}
	
	public int uploadCategory(CategoryDTO dto2) {
		return dao.addCategory(dto2);
	}

	public int modifyCategory(RecipeDTO dto) {
		return dao.modifyCategory(dto);
	}

	public List<RecipeDTO> getLikeHeart(int userIdx) {
		return dao.getLikeHeart(userIdx);
	}




}
