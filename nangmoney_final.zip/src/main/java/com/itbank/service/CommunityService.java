package com.itbank.service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.itbank.repository.CommunityDAO;
import com.itbank.component.UploadComponent;
import com.itbank.model.CommunityDTO;
import com.itbank.model.CommunityUploadDTO;
import com.itbank.model.Paging;

@Service
public class CommunityService {

	@Autowired
	private CommunityDAO dao;
	@Autowired
	private UploadComponent uploadComponent;
	
	String linuxPath = "/upload_community";
	String windowsPath = "C:\\upload_community";
	
	String sep = File.separator;
	
	private final String saveDirectory = "\\".equals(sep) ? windowsPath : linuxPath;

	public int getCommunitySearchCount(String communityTitle) {
		return dao.selectSearchCommunityCount(communityTitle);
	}

	public int getCommunityCount() {
		return dao.selectCommunityCount();
	}

	public List<CommunityDTO> search(String communityTitle, Paging paging) {
		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("offset", paging.getOffset());
		param.put("perPage", paging.getPerPage());
		param.put("communityTitle", communityTitle);

		return dao.search(param);
	}

	public List<CommunityDTO> getListAll(Paging paging) {
		HashMap<String, Object> param = new HashMap<String, Object>();
		param.put("offset", paging.getOffset());
		param.put("perPage", paging.getPerPage());

		return dao.selectAll(param);
	}

	public CommunityDTO get(int communityIdx) {
		dao.viewCount(communityIdx);
		return dao.selectOne(communityIdx);
	}

	
	private String makeNewName(String getCommunityTitle, String pastName, String imageType) {
		String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
		String ext = pastName.substring(pastName.lastIndexOf("."));
		String realName = today + "_" + getCommunityTitle + "_" + imageType;
		realName += ext;
		return realName;
	}
	

	public int write(CommunityDTO dto) throws IllegalStateException, IOException {
		
		int row = 0;
		int communityIdx;
		int size = dto.getMyRecipeImage().size();
		
		// 업로드
		List<MultipartFile> myRecipeImage = dto.getMyRecipeImage();
	    List<String> oldNames = Arrays.asList(myRecipeImage.stream().map(e -> e.getOriginalFilename()).toArray(String[]::new));
	    List<String> newNames = dto.getNewNameList();
	    List<String> communityContent = dto.getCommunityContent();
	    
		for(MultipartFile f : myRecipeImage) {
			dto.getNewNameList().add(uploadComponent.upload(f));
		}
		
		
		MultipartFile thumbnail = dto.getThumbnailFile();
		String realName = makeNewName(dto.getCommunityTitle(), thumbnail.getOriginalFilename(), "thumbnail");
		File dest = new File(saveDirectory, realName);
		try {
			thumbnail.transferTo(dest);		
			dto.setThumbnail(realName);
			
			row = dao.insert(dto);
			
		} catch(IllegalStateException | IOException e) {
			e.printStackTrace();
		}
		
		
		// DB추가
		communityIdx = dao.selectLastIdx();
		dto.setCommunityIdx(communityIdx);
		for(int i = 0; i < size; i++) {
			HashMap<String, Object> param = new HashMap<String, Object>();
			param.put("communityIdx", communityIdx);
			param.put("oldName", oldNames.get(i));
			param.put("newName", newNames.get(i));
			param.put("communityContent", communityContent.get(i));
			dao.insertUploadImage(param);
		}
		
		return row;
	}
	
	public List<HashMap<String, String>> getCommunity(int offset) {
		return dao.getCommunity(offset);
	}

	public List<String> getImages(int idx) {
		return dao.getImages(idx);
	}

//	썸네일&타이틀만 수정함
	public int modify(CommunityDTO dto){
	
		MultipartFile thumbnailFile = dto.getThumbnailFile();
		String realName = makeNewName(dto.getCommunityTitle(), thumbnailFile.getOriginalFilename(), "thumbnail");
		
		if(thumbnailFile.getSize() != 0) {
			File oldFile = new File(saveDirectory, dto.getThumbnail());
			if(oldFile.exists()) {
				oldFile.delete();
			}
			realName = makeNewName(dto.getCommunityTitle(), thumbnailFile.getOriginalFilename(), "thumbnail");
			File dest = new File(saveDirectory, realName);
			try {
				dto.getThumbnailFile().transferTo(dest);
				dto.setThumbnail(realName);
				int row = dao.modify(dto);
				return row;
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		}
		if(!realName.equals(dto.getThumbnail())) {
			File file1 = new File(saveDirectory, dto.getThumbnail());
			File file2 = new File(saveDirectory, realName);
			file1.renameTo(file2);
		}

		
		dto.setThumbnail(realName);	
		return dao.modify(dto);
	}
	public int delete(CommunityDTO dto, List<String> list) {
		list.forEach(e -> {
			File oldFile = new File(saveDirectory, e);
			if(oldFile.exists()) {
				oldFile.delete();
			}
		});
		int row = dao.deleteUploadfiles(dto.getCommunityIdx());
		
		File file = new File(saveDirectory, dto.getThumbnail());
		int idx = dto.getCommunityIdx();
	      if(file.exists()) {
	    	 file.delete();
	      }
		return dao.delete(idx);
	}

	public List<CommunityUploadDTO> getUploadFile(int communityIdx) {
		return dao.getUploadFile(communityIdx);
	}

	public List<String> getUploadFileNewName(int communityIdx) {
		return dao.selectUploadFileNewName(communityIdx);
	}

	public CommunityUploadDTO getImage(int imageIdx) {
		return dao.getImage(imageIdx);
	}
	
//	업로드파일 수정용으로 추가
	public int modify_uploadFile(CommunityUploadDTO dto) {
		
		MultipartFile modifyFile = dto.getModifyFile();
		String newName2 = UUID.randomUUID().toString().replaceAll("-", "");
		System.out.println(dto.getNewName());
		if(modifyFile.getSize() != 0) {
			File oldFile = new File(saveDirectory, dto.getNewName());
			if(oldFile.exists()) {
				oldFile.delete();
			}
			String newName = UUID.randomUUID().toString().replaceAll("-", "");
			File dest = new File(saveDirectory, newName);
			try {
				dto.getModifyFile().transferTo(dest);
				dto.setNewName(newName);
				int row = dao.modify_uploadFile(dto);
				return row;
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
		}
		if(!newName2.equals(dto.getNewName())) {
			File file1 = new File(saveDirectory, dto.getNewName());
			File file2 = new File(saveDirectory, newName2);
			file1.renameTo(file2);
		}

		
		dto.setNewName(newName2);	
		return dao.modify_uploadFile(dto);
	}

//	뷰 페이지에서 추가작성을 위해 추가
	public int modify_add(CommunityDTO dto) throws IllegalStateException, IOException {
		int row = 0;
		int communityIdx = dto.getCommunityIdx();
		int size = dto.getMyRecipeImage().size();
		
		// 업로드
		List<MultipartFile> myRecipeImage = dto.getMyRecipeImage();
	    List<String> oldNames = Arrays.asList(myRecipeImage.stream().map(e -> e.getOriginalFilename()).toArray(String[]::new));
	    List<String> newNames = dto.getNewNameList();
	    List<String> communityContent = dto.getCommunityContent();
	    
		for(MultipartFile f : myRecipeImage) {
			dto.getNewNameList().add(uploadComponent.upload(f));
		}
		
		// DB추가
		
		for(int i = 0; i < size; i++) {
			HashMap<String, Object> param = new HashMap<String, Object>();
			param.put("communityIdx", communityIdx);
			param.put("oldName", oldNames.get(i));
			param.put("newName", newNames.get(i));
			param.put("communityContent", communityContent.get(i));
			dao.insertUploadImage(param);
		}
		
		return row;
	}



}
