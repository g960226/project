package com.itbank.service;


public class CommunityUploadDTO {
	private int communityIdx;
	private int imageIdx;
	private String oldName;
	private String newName;
	private String communityContent;
	
	
	public int getCommunityIdx() {
		return communityIdx;
	}
	public void setCommunityIdx(int communityIdx) {
		this.communityIdx = communityIdx;
	}
	public int getImageIdx() {
		return imageIdx;
	}
	public void setImageIdx(int imageIdx) {
		this.imageIdx = imageIdx;
	}
	public String getOldName() {
		return oldName;
	}
	public void setOldName(String oldName) {
		this.oldName = oldName;
	}
	public String getNewName() {
		return newName;
	}
	public void setNewName(String newName) {
		this.newName = newName;
	}
	public String getCommunityContent() {
		return communityContent;
	}
	public void setCommunityContent(String communityContent) {
		this.communityContent = communityContent;
	}
	
	
}
