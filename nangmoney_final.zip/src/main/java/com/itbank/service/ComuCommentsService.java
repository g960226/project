package com.itbank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.model.ComuCommentsDTO;
import com.itbank.repository.ComuCommentsDAO;


@Service
public class ComuCommentsService {

	@Autowired ComuCommentsDAO dao;
	
	public List<ComuCommentsDTO> commentsList(int communityIdx) {
		return dao.getCommentsList(communityIdx);
	}

	public int writeComments(ComuCommentsDTO dto) {
		return dao.writeComments(dto);
	}

	public int delete(int comuCommentsIdx) {
		return dao.delete_comments(comuCommentsIdx);
	}


}
