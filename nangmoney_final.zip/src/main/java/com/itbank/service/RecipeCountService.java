package com.itbank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.itbank.model.RecipeCountDTO;
import com.itbank.repository.RecipeCountDAO;
import com.itbank.repository.RecipeDAO;

@Service
public class RecipeCountService {

	@Autowired private RecipeCountDAO recipeCountDao;
	@Autowired private RecipeDAO recipeDao;
	
	// 재료별 개수 데이터 불러옴
	public RecipeCountDTO getRecipeDataList() {
		return recipeCountDao.getRecipeDataList();
	}
	
	
	public RecipeCountDTO setRecipeData() {
		RecipeCountDTO dto = new RecipeCountDTO();
		int beef = recipeDao.getBeef();
		int pork = recipeDao.getPork();
		int chicken = recipeDao.getChicken();
		int meat = recipeDao.getMeat();
		int ham = recipeDao.getHam();
		int salmon = recipeDao.getSalmon();
		int tuna = recipeDao.getTuna();
		int noodle = recipeDao.getNoodle();
		int seafood = recipeDao.getSeafood();
		int bread = recipeDao.getBread();
		int algae = recipeDao.getAlage();
		int tofu = recipeDao.getTofu();
		int fishCake = recipeDao.getFishcake();
		int kimchi = recipeDao.getKimchi();
		int onion = recipeDao.getOnion();
		int mushroom = recipeDao.getMushroom();
		int egg = recipeDao.getEgg();
		int garlic = recipeDao.getGarlic();
		int greenOnion = recipeDao.getGreenOnion();
		int potato = recipeDao.getPotato();
		int pepper = recipeDao.getPepper();
		int squash = recipeDao.getSquash();
		int vegetables = recipeDao.getVegetables();
		int miso = recipeDao.getMiso();
		int chiliPepperPaste = recipeDao.getChiliPepperPaste();
		int soySauce = recipeDao.getSoySauce();
		int tomatoSauce = recipeDao.getTomatoSauce();
		int butter = recipeDao.getButter();
		int mayonnaise = recipeDao.getMayonnaise();
		int mara = recipeDao.getMara();
		int ketchup = recipeDao.getKetchup();
		int condiment = recipeDao.getCondiment();
		int curry = recipeDao.getCurry();
		int jjajang = recipeDao.getJjajang();
		int bronze = recipeDao.getBronze();
		int silver = recipeDao.getSilver();
		int gold = recipeDao.getGold();
		int mommyHand = recipeDao.getMommyHand();
		
		dto.setBeef(beef);
		dto.setPork(pork);
		dto.setChicken(chicken);
		dto.setMeat(meat);
		dto.setHam(ham);
		dto.setSalmon(salmon);
		dto.setTuna(tuna);
		dto.setNoodle(noodle);
		dto.setSeafood(seafood);
		dto.setBread(bread);
		dto.setAlgae(algae);
		dto.setTofu(tofu);
		dto.setFishCake(fishCake);
		dto.setKimchi(kimchi);
		dto.setOnion(onion);
		dto.setMushroom(mushroom);
		dto.setEgg(egg);
		dto.setGarlic(garlic);
		dto.setGreenOnion(greenOnion);
		dto.setPotato(potato);
		dto.setPepper(pepper);
		dto.setSquash(squash);
		dto.setVegetables(vegetables);
		dto.setMiso(miso);
		dto.setChiliPepperPaste(chiliPepperPaste);
		dto.setSoySauce(soySauce);
		dto.setTomatoSauce(tomatoSauce);
		dto.setButter(butter);
		dto.setMayonnaise(mayonnaise);
		dto.setMara(mara);
		dto.setKetchup(ketchup);
		dto.setcondiment(condiment);
		dto.setCurry(curry);
		dto.setJjajang(jjajang);
		dto.setBronze(bronze);
		dto.setSilver(silver);
		dto.setGold(gold);
		dto.setMommyHand(mommyHand);
		return dto;
	}


	public void setRecipeCountData() {
		RecipeCountDTO rcDto = setRecipeData();
		recipeCountDao.setRecipeCountData(rcDto);
	}


	public List<RecipeCountDTO> getMainIngList() {
		return recipeCountDao.getMainIngData();
	}
}
