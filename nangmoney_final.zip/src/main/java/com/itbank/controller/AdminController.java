package com.itbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.model.CategoryDTO;
import com.itbank.model.CommentsDTO;
import com.itbank.model.CommunityDTO;
import com.itbank.model.ComuCommentsDTO;
import com.itbank.model.MemberDTO;
import com.itbank.model.RecipeCountDTO;
import com.itbank.model.RecipeDTO;
import com.itbank.service.AdminService;
import com.itbank.service.CommunityService;
import com.itbank.service.ComuCommentsService;
import com.itbank.service.FileService;
import com.itbank.service.RecipeCountService;
import com.itbank.service.RecipeService;

@Controller
public class AdminController {
	
	@Autowired private AdminService adminService;
	@Autowired private FileService fileService;
	@Autowired private RecipeService recipeService;
	@Autowired private RecipeCountService recipeCountService;
	@Autowired private CommunityService communityService;
	@Autowired private ComuCommentsService comuCommentsService;
	
	@GetMapping("/admin/management")
	public ModelAndView management() {
		ModelAndView mav = new ModelAndView("/admin/management");
		return mav;
	}
	
	@GetMapping("/admin/member_management")
	public ModelAndView list() {
		ModelAndView mav = new ModelAndView("/admin/member_management");
		List<MemberDTO> list = adminService.getList_member();
		mav.addObject("list", list);
		return mav;
	}
	@PostMapping("/admin/member_management")
	public ModelAndView search(String userName) {
		ModelAndView mav = new ModelAndView("/admin/member_management");
		List<MemberDTO> list = adminService.getSearchList(userName);
		mav.addObject("list",list);
		mav.addObject("show", "show");
		return mav;
	}
	
	@GetMapping("/delete_member/{userIdx}")
	public ModelAndView deleteMember(@PathVariable("userIdx") int userIdx) {
		ModelAndView mav = new ModelAndView("redirect:/admin/member_management");
		int row = adminService.delete_member(userIdx);
		mav.addObject("msg", "delete:" + (row != 0 ? " success": "failure"));
		return mav;
	}
	
	// 회원별로 comments 불러오기 
	@GetMapping("/admin/member_management_comments/{userIdx}")
	public ModelAndView comments_user(@PathVariable("userIdx")int userIdx) {
		ModelAndView mav = new ModelAndView("/admin/member_management_comments");
		List<CommentsDTO> list = adminService.getUserCommentsList(userIdx);
		mav.addObject("list" , list);
		return mav;
	}
	
	// fileService부분 추가
	@GetMapping("/delete_recipe/{recipeIdx}")
	public ModelAndView deleteRecipe(@PathVariable("recipeIdx") int recipeIdx) {
		ModelAndView mav = new ModelAndView("redirect:/admin/recipe_management");
		
		RecipeDTO dto = adminService.getRecipeDTO(recipeIdx);
		fileService.deleteFile(dto.getRecipeThumbNail());
		
		int row = adminService.delete_recipe(recipeIdx);
		mav.addObject("msg", "delete:" + (row != 0 ? "success" : "failure"));
		return mav;
	}
	
	
	@GetMapping("/admin/recipe_management")
	public ModelAndView list_recipe() {
		ModelAndView mav = new ModelAndView("/admin/recipe_management");
		List<RecipeDTO> list = adminService.getList_recipe();
		mav.addObject("list",list);
		return mav;
	}
	@PostMapping("/admin/recipe_management")
	public ModelAndView search_recipe(String recipeName) {
		ModelAndView mav = new ModelAndView("/admin/recipe_management");
		List<RecipeDTO> list = adminService.getSearchRecipeList(recipeName);
		List<CategoryDTO> list2 = adminService.getSearchCategoryList();
		mav.addObject("list",list);
		mav.addObject("list2", list2);
		mav.addObject("show", "show");
		return mav;
	}
	

	// 회원별 comments 삭제
	@GetMapping("/delete_comments/{commentsIdx}")
	public ModelAndView deleteComments(@PathVariable("commentsIdx") int commentsIdx, 
	@RequestHeader(value="referer") String referer) {
		
		ModelAndView mav = new ModelAndView("redirect:" + referer);
		int row = adminService.delete_comments(commentsIdx);
		System.out.println(row);
		return mav;
	}
	
	@GetMapping("/admin/recipe_add")
	public ModelAndView add() {
		ModelAndView mav = new ModelAndView("/admin/recipe_add");
		return mav;
	}
	
	// 레시피 추가
	@PostMapping("/admin/recipe_add")
	public ModelAndView add(RecipeDTO dto, CategoryDTO dto2) {
		ModelAndView mav = new ModelAndView("redirect:/admin/recipe_management");
		int idx = fileService.uploadRecipe(dto);
		dto2.setRecipeIdx(idx);
		int idx2 = recipeService.uploadCategory(dto2);
		recipeCountService.setRecipeCountData();
		System.out.println(idx2 > 0 ? "성공" : "실패");
		return mav;
	}
	
	@GetMapping("/admin/recipe_modify/{recipeIdx}")
	public ModelAndView modify(@PathVariable("recipeIdx")int recipeIdx) {
		ModelAndView mav = new ModelAndView("/admin/recipe_modify");
		RecipeDTO dto = adminService.getRecipeDTO(recipeIdx);
		mav.addObject("dto", dto);
		return mav;
	}
	
	@PostMapping("/admin/recipe_modify/{recipeIdx}")
	public ModelAndView modify(RecipeDTO dto) {
		ModelAndView mav = new ModelAndView("redirect:/admin/recipe_management");
		int row1 = fileService.modifyRecipe(dto);
		int row2 = recipeService.modifyCategory(dto);
		System.out.println(row1 != 0 && row2 != 0 ? "성공" : "실패");
		return mav;
	}
	
	//재료별 데이터 개수 테이블 불러오기
	@GetMapping("/admin/recipe_dataList")
	public ModelAndView recipeDataList() {
		ModelAndView mav = new ModelAndView("/admin/recipe_dataList");
		RecipeCountDTO dto = recipeCountService.getRecipeDataList();
		System.out.println(dto.getBeef());
		mav.addObject("dto", dto);
		return mav;
	}
	
	
	@GetMapping("/admin/community_management")
	public ModelAndView communityList() {
		ModelAndView mav = new ModelAndView("/admin/community_management");
		List<CommunityDTO> list = adminService.getList_commnuity();
		mav.addObject("list", list);
		return mav;
		
	}
	
	@GetMapping("/delete_community/{communityIdx}")
	public ModelAndView deleteCommunity(@PathVariable("communityIdx") int communityIdx) {
		ModelAndView mav = new ModelAndView("redirect:/admin/community_management");
		CommunityDTO dto = communityService.get(communityIdx);
		List<String> list = communityService.getUploadFileNewName(communityIdx);
		int row = communityService.delete(dto,list);
		mav.addObject("msg", "delete:" + (row != 0 ? " success": "failure"));
		return mav;
	}
	
	@GetMapping("/admin/community_management_comments/{communityIdx}")
	public ModelAndView community_comments(@PathVariable("communityIdx")int communityIdx) {
		ModelAndView mav = new ModelAndView("/admin/community_management_comments");
		List<ComuCommentsDTO> list = comuCommentsService.commentsList(communityIdx);
		mav.addObject("list" , list);
		return mav;
	}
	
	@GetMapping("/delete_Comcomments/{idx}")
	public ModelAndView deleteComuComments(@PathVariable("idx") int idx, 
	@RequestHeader(value="referer") String referer) {
		ModelAndView mav = new ModelAndView("redirect:" + referer);
		int row = comuCommentsService.delete(idx);
		System.out.println(row);
		return mav;
	}
	
		
}
