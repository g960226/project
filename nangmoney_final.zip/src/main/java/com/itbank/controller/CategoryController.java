package com.itbank.controller;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.model.CategoryDTO;
import com.itbank.model.RecipeDTO;
import com.itbank.service.CategoryService;



@Controller
public class CategoryController {

	@Autowired private CategoryService categoryService;
	
	@GetMapping("/category/category_recipe")
	public ModelAndView newrecipe() {
		ModelAndView mav = new ModelAndView("/category/category_recipe");
		List<RecipeDTO> list = categoryService.getRecipeList();
		mav.addObject("list", list);
		mav.addObject("activeMenu", 0);
		return mav;
	}
	
	@PostMapping("/category/category_recipe")
	@ResponseBody
	public List<RecipeDTO> selectIngredient(@RequestBody CategoryDTO dto) {
		
		List<RecipeDTO> list= categoryService.selectIngredient(dto);
		return list;
	}
	
	@GetMapping("/category/category_detail/{recipeIdx}")
	public ModelAndView newRecipeDetail(@PathVariable("recipeIdx") int recipeIdx,
			@CookieValue(value = "recentList", required = false) Cookie incomeCookie, 
			HttpServletRequest request,
			HttpServletResponse response,
			HttpSession session,
			@RequestParam(defaultValue="true") boolean flag) {
		
		ModelAndView mav = new ModelAndView("/category/category_detail");
		int userIdx = 0;
		if(session.getAttribute("userIdx") != null) {
			userIdx = (Integer)session.getAttribute("userIdx");
		} else {
			userIdx = 0;
		}
		
		if (flag == false) {
			makeCookie(recipeIdx, incomeCookie, request, response);
			mav.setViewName("redirect:/category/category_detail/" + recipeIdx);
		} else {
			RecipeDTO dto = categoryService.getRecipeDTO(recipeIdx, userIdx);
			mav.addObject("dto", dto);
		}
		return mav;
	}
	
	// 쿠키를 만드는 코드
	private void makeCookie(int recipeIdx, Cookie incomeCookie, HttpServletRequest request, HttpServletResponse response) {

		String incomeCookieValue = "";
		if (incomeCookie != null) {
			incomeCookieValue = incomeCookie.getValue();
		}

		ArrayList<String> list = new ArrayList<String>(Arrays.asList(incomeCookieValue.split("_")));

		if (list.contains(recipeIdx + "") == false) {
			list.add(String.valueOf(recipeIdx));
		} else {
			String contain = recipeIdx + "";
			list.remove(contain);
			list.add(contain);
		}
		if (list.size() > 3) {
			list.remove(0);
		}

		String newCookieValue = String.join("_", list);

		if (newCookieValue.startsWith("_"))
			newCookieValue = newCookieValue.substring(1, newCookieValue.length());


		Cookie newCookie = new Cookie("recentList", newCookieValue);
		newCookie.setMaxAge(60 * 60 * 24 * 7);
		newCookie.setPath(request.getContextPath());
		response.addCookie(newCookie);
	}
}
