package com.itbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itbank.model.CommentsDTO;
import com.itbank.service.CommentsService;

@RestController
@RequestMapping("/category/comments")
public class CommentsController {
	
	@Autowired private CommentsService commentsService;
	
	@GetMapping("/{recipeIdx}")
	public List<CommentsDTO> comments(@PathVariable int recipeIdx) {
		List<CommentsDTO> list = commentsService.commentsList(recipeIdx);
		return list;
	}
	
	@PostMapping("/{recipeIdx}")
	public int writeComments(@RequestBody CommentsDTO dto) {
		int row = commentsService.writeComments(dto);
		return row;
	}
	
	@DeleteMapping("/{recipeIdx}/{idx}")
	public int deleteComments(@PathVariable("idx") int idx) {
		int row = commentsService.delete(idx);
		return row;
	}
	
	@GetMapping("/modify/{recipeIdx}/{idx}")
	public CommentsDTO commentsUpdate(@PathVariable int idx) {
		CommentsDTO dto = commentsService.commentsSelectOne(idx);
		return dto;
	}
	
}
