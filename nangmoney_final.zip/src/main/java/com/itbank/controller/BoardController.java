package com.itbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.model.Paging;
import com.itbank.model.RecipeDTO;
import com.itbank.service.BoardService;
import com.itbank.service.RecipeService;


@Controller
public class BoardController {

	@Autowired private BoardService boardService;
	@Autowired private RecipeService recipeService;
	
	@GetMapping("/board/newrecipe")
	public ModelAndView newrecipe() {
	ModelAndView mav = new ModelAndView("/board/newrecipe");
	List<RecipeDTO> list = boardService.getNewrecipe();
	mav.addObject("list", list);
	mav.addObject("activeMenu", 2);
	return mav;
	}
	
	@GetMapping("/board/awards")
	public ModelAndView awards() {
		ModelAndView mav = new ModelAndView("/board/awards");
		
		List<RecipeDTO> list1 = boardService.getPopularScore();
		List<RecipeDTO> list2 = recipeService.getPopList();
		List<RecipeDTO> list3 = boardService.getPopularLikeSum();
		
		mav.addObject("list1", list1);
		mav.addObject("list2", list2);
		mav.addObject("list3", list3);
		mav.addObject("activeMenu", 1);
		return mav;
	}
	
	@GetMapping("/board/searchList")
	public ModelAndView list(@RequestParam(defaultValue="1") Integer page, @RequestParam("recipeName") String recipeName) {   
		ModelAndView mav = new ModelAndView();
		
		int boardCount = 0;
	    Paging paging = null;      
	    List<RecipeDTO> list = null;      
	      
	    if(recipeName != "") {
	    boardCount = boardService.getBoardSearchCount(recipeName);
	    paging = new Paging(page, boardCount);
	    list = boardService.search(recipeName, paging);         
	    } else {
	    	boardCount = boardService.getBoardCount();
	        paging = new Paging(page, boardCount);
	        list = boardService.getListAll(paging);
	        }
	    mav.addObject("recipeName", recipeName);
	    mav.addObject("list", list);
	    mav.addObject("paging", paging);
	    mav.addObject("activeSearchMenu", 0);
	    mav.addObject("activeMenu", 10);
	      
	    return mav;  
	}
}
