package com.itbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itbank.model.AwardDTO;
import com.itbank.service.BoardService;

@RestController
public class AwardController {
	
	@Autowired private BoardService boardService;
	
	@GetMapping("/awardsIng1")
	public List<AwardDTO> getAwardsIng1Chart() {
		List<AwardDTO> awardIng1List = boardService.getPopularAwardIng1();
		return awardIng1List;
	}

}
