package com.itbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.model.RecipeDTO;
import com.itbank.service.RecipeService;

@Controller
public class HomeController {
	
	@Autowired
	private RecipeService recipeService;

	@GetMapping("/")
	public ModelAndView home() {
		ModelAndView mav = new ModelAndView("home");
		List<RecipeDTO> list = recipeService.getList();	
		List<RecipeDTO> list2 = recipeService.getPopList();
		mav.addObject("list", list);
		mav.addObject("list2", list2);
		mav.addObject("activeMenu", 10);
		return mav;
	}
	

}
