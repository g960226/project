package com.itbank.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.itbank.component.HashComponent;
import com.itbank.model.MemberDTO;
import com.itbank.model.RecipeDTO;
import com.itbank.service.MemberService;
import com.itbank.service.RecipeService;

@Controller
public class MemberController {
	
	@Autowired private MemberService memberService;
	@Autowired private RecipeService recipeService;
	@Autowired private HashComponent hashComponent;
	
	@GetMapping("/member/join")
	public ModelAndView join() {
		ModelAndView mav = new ModelAndView("/member/join");
		return mav;
	}
	@GetMapping("/member/joinKakao")
	public ModelAndView joinKakao(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("/member/joinKakao");
		MemberDTO dto = new MemberDTO();
		dto.setUserEmail(request.getParameter("userEmail"));
		dto.setUserPw(request.getParameter("userPw"));
		dto.setUserName(request.getParameter("userName"));
		dto.setNickName(request.getParameter("nickName"));
		dto.setAge(request.getParameter("age"));
		dto.setUserGroups(2);
		mav.addObject("dto", dto);
		return mav;
	}
	
	@PostMapping("/member/join")
	public ModelAndView join(MemberDTO dto) {
		ModelAndView mav = new ModelAndView("redirect:/");
		dto.setUserPw(hashComponent.getHash(dto.getUserPw()));
		memberService.add(dto);
		return mav;
	}
	
	@PostMapping("/member/joinKakao")
	public ModelAndView joinKakao(MemberDTO dto) {
		ModelAndView mav = new ModelAndView("redirect:/");
		System.out.println(dto.getUserGroups());
		memberService.add(dto);
		return mav;
	}
	
	@GetMapping("/member/login") 
	public ModelAndView login() {
		ModelAndView mav = new ModelAndView("/member/login");
		return mav;
	}
	

	@PostMapping("/member/login")
	public ModelAndView login(MemberDTO dto, HttpSession session, String url, HttpServletRequest req, RedirectAttributes rttr) {
		ModelAndView mav = new ModelAndView();
		
		String ip = req.getHeader("X-FORWARDED-FOR");

        if (ip == null) {
            ip = req.getRemoteAddr();
        }
		dto.setUserPw(hashComponent.getHash(dto.getUserPw()));
		mav.addObject("clientIP", ip);
		session.setAttribute("ip", ip);
		
		MemberDTO login = memberService.login(dto);
		if(login != null) {
			session.setAttribute("member", login);
			session.setAttribute("userIdx", login.getUserIdx());
			
			if(login.getUserGroups() == 1) {
			mav.setViewName("redirect:/admin/management");
			return mav;
			
			} else mav.setViewName("redirect:/");
			
		} else {
			session.setAttribute("member", null);
			mav.setViewName("redirect:/member/login");
			rttr.addFlashAttribute("msg", false);
		}


		return mav;
	}
	
	@GetMapping("/member/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@GetMapping("/member/mypage")
	public ModelAndView mypage(HttpSession session) {
		ModelAndView mav = new ModelAndView("/member/mypage");
		int userIdx = (Integer)session.getAttribute("userIdx");
		MemberDTO dto = memberService.getMypage(userIdx);
		mav.addObject("dto", dto);
		mav.addObject("activeMenu", 10);
		return mav;
	}
	
	@PostMapping("/member/mypage")
	public ModelAndView modifyMypage(MemberDTO dto) {
		ModelAndView mav = new ModelAndView("redirect:/");
		dto.setUserPw(hashComponent.getHash(dto.getUserPw()));
		int row = memberService.modifyMypage(dto);
		System.out.println(row != 0 ? "성공" : "실패");
		return mav;
	}
	
	@GetMapping("/member/likeHeart")
	public ModelAndView mypage_main(HttpSession session) {
		ModelAndView mav = new ModelAndView("/member/likeHeart");
		int userIdx = (Integer)session.getAttribute("userIdx");
		MemberDTO dto = memberService.getMypage(userIdx);
		List<RecipeDTO> list = recipeService.getLikeHeart(userIdx);
		mav.addObject("dto", dto);
		mav.addObject("list", list);
		return mav;
	}
		
	@GetMapping("/member/modifyPw")
	public ModelAndView modifyPw(HttpSession session) {
		ModelAndView mav = new ModelAndView("/member/modifyPw");
		int userIdx = (Integer)session.getAttribute("userIdx");
		MemberDTO dto = memberService.getMypage(userIdx);
		mav.addObject("dto",dto);
		return mav;
	}
	
	@PostMapping("/member/modifyPw")
	public ModelAndView modifyPw(HttpSession session, MemberDTO dto) {
		ModelAndView mav = new ModelAndView("redirect:/member/mypage"); 
		dto.setUserPw(hashComponent.getHash(dto.getUserPw()));
		memberService.modifyPw(dto);
		return mav;
	}
		
	@GetMapping("/member/pwCheck")
	public ModelAndView pwCheck(HttpSession session) {
		ModelAndView mav = new ModelAndView("/member/pwCheck");
		int userIdx = (Integer)session.getAttribute("userIdx");
		MemberDTO dto = memberService.getMypage(userIdx);
		mav.addObject("dto", dto);
		return mav;
	}
	
	@GetMapping("/withdraw_member")
	public ModelAndView withdrawMember(HttpSession session) {
		ModelAndView mav = new ModelAndView("redirect:/");
		int userIdx = (Integer)session.getAttribute("userIdx");
		int row = memberService.withdraw_member(userIdx);
		session.invalidate();
		mav.addObject("msg", "delete:" + (row != 0 ? " success": "failure"));
		return mav;
	}
	
	
}
