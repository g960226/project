package com.itbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itbank.model.ComuCommentsDTO;
import com.itbank.service.ComuCommentsService;

@RestController
@RequestMapping("/community/comuComments")
public class ComuCommentsController {
	
	@Autowired private ComuCommentsService comuCommentsService;
	
	@GetMapping("/{communityIdx}")
	public List<ComuCommentsDTO> comuComments(@PathVariable int communityIdx) {
		List<ComuCommentsDTO> list = comuCommentsService.commentsList(communityIdx);
		return list;
	}
	
	@PostMapping("/{communityIdx}")
	public int writeComments(@RequestBody ComuCommentsDTO dto) {
		int row = comuCommentsService.writeComments(dto);
		return row;
	}
	
	@DeleteMapping("/{communityIdx}/{idx}")
	public int deleteComments(@PathVariable("idx") int idx) {
		int row = comuCommentsService.delete(idx);
		return row;
	}

}

