package com.itbank.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.model.CommunityDTO;
import com.itbank.model.CommunityUploadDTO;
import com.itbank.model.Paging;
import com.itbank.service.CommunityService;

@Controller
public class CommunityController {
	
	@Autowired private CommunityService communityService;
	
	@GetMapping("/community/communityList")
		public ModelAndView list(@RequestParam(defaultValue="1") Integer page, @RequestParam(value="communityTitle", required=false) String communityTitle) {   
			ModelAndView mav = new ModelAndView();
			
			int communityCount = 0;
		    Paging paging = null;      
		    List<CommunityDTO> list = null;      
		      
		    if(communityTitle != "") {
		    communityCount = communityService.getCommunitySearchCount(communityTitle);
		    paging = new Paging(page, communityCount);
		    list = communityService.search(communityTitle, paging);         
		    } else {
		    	communityCount = communityService.getCommunityCount();
		        paging = new Paging(page, communityCount);
		        list = communityService.getListAll(paging);
		        }
		    mav.addObject("communityTitle", communityTitle);
		    mav.addObject("list", list);
		    mav.addObject("paging", paging);
		    mav.addObject("activeCommunityList", 0);
			mav.addObject("activeMenu", 3);
		      
		    return mav;  
		}
	
	@GetMapping("/community/view/{communityIdx}")
	public ModelAndView view(@PathVariable("communityIdx") int communityIdx) {
		ModelAndView mav = new ModelAndView("/community/view");
		CommunityDTO dto = communityService.get(communityIdx);
		List<CommunityUploadDTO> list = communityService.getUploadFile(communityIdx);
		mav.addObject("dto", dto);
		mav.addObject("list", list);
		mav.addObject("activeMenu", 3);
		return mav;
	}
	
//	뷰 페이지에서 추가작성을 위해 추가
	@PostMapping("/community/view/{communityIdx}")
	public String view(CommunityDTO dto, HttpServletRequest request) throws IllegalStateException, IOException {
		int row = communityService.modify_add(dto);
		return "redirect:/community/view/" + dto.getCommunityIdx();
	}
	
	@GetMapping("/community/write")
	public ModelAndView write() {
		ModelAndView mav = new ModelAndView("/community/write");
		mav.addObject("activeMenu", 3);
		return mav;
	}
	
	@PostMapping("/community/write")
	public String write(CommunityDTO dto, HttpServletRequest request) throws IllegalStateException, IOException {
		dto.setIpaddr(request.getRemoteAddr());
		int row = communityService.write(dto);
		return "redirect:/community/communityList";
	}
	
	@GetMapping("/community/modify/{communityIdx}")
	public ModelAndView modify(@PathVariable("communityIdx") int communityIdx) {
		ModelAndView mav = new ModelAndView("/community/modify");
		CommunityDTO dto = communityService.get(communityIdx);
		mav.addObject("dto", dto);
		mav.addObject("activeMenu", 3);
		return mav;
	}
	
	@PostMapping("/community/modify/{communityIdx}")
	public ModelAndView modify(CommunityDTO dto) {
		ModelAndView mav = new ModelAndView("redirect:/community/view/" + dto.getCommunityIdx());
		int row = communityService.modify(dto);
		return mav;
	}
	
//	업로드파일 수정용으로 추가
	@GetMapping("/community/modify_uploadFile/{imageIdx}")
	public ModelAndView modify_uploadFile(@PathVariable("imageIdx") int imageIdx) {
		ModelAndView mav = new ModelAndView("/community/modify_uploadFile");
		CommunityUploadDTO dto = communityService.getImage(imageIdx);
		mav.addObject("dto", dto);
		mav.addObject("activeMenu", 3);
		return mav;
	}
	
	@PostMapping("/community/modify_uploadFile/{imageIdx}")
	public ModelAndView modify_uploadFile(CommunityUploadDTO dto) {
		ModelAndView mav = new ModelAndView("redirect:/community/view/" + dto.getCommunityIdx());
		int row = communityService.modify_uploadFile(dto);
		return mav;
	}

	
	@GetMapping("/community/delete/{communityIdx}")
	public String delete(@PathVariable("communityIdx") int communityIdx) {
		CommunityDTO dto = communityService.get(communityIdx);
		List<String> list = communityService.getUploadFileNewName(communityIdx);
		int row = communityService.delete(dto,list);
		return "redirect:/community/communityList";
	}

}
