package com.itbank.controller;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itbank.component.HashComponent;
import com.itbank.model.CommentsDTO;
import com.itbank.model.MemberDTO;
import com.itbank.model.RecipeCountDTO;
import com.itbank.service.AdminService;
import com.itbank.service.HeartService;
import com.itbank.service.MemberService;
import com.itbank.service.RecipeCountService;

@RestController
public class AjaxController {
	
	@Autowired private MemberService memberService;
	@Autowired private AdminService adminService;
	@Autowired private RecipeCountService recipeCountService;
	@Autowired private HeartService heartService;
	@Autowired private HashComponent hashComponent;
	
	private ObjectMapper mapper = new ObjectMapper();
	
	private HashMap<String, String> authNumberMap = new HashMap<String, String>();
	
	@GetMapping("/dupCheck/{inputId}/")
	@ResponseBody
	public String dupCheck(@PathVariable("inputId") String inputId) {
		int row = memberService.dupCheck(inputId);
		if(inputId == "200") {
			int row2 = 1;
			String msg2 = "아이디를 입력하세요";
			msg2 = row2 + ":" + msg2;
			return msg2;
		}
		String msg = row == 1 ? "이미 사용중인 ID 입니다" : "사용 가능한 Email 입니다";
		msg = row + ":" + msg;
		return msg;
	}
	
	@GetMapping("/nicknameDupResult/{inputNickName}")
	@ResponseBody
	public String nicknameDupResult(@PathVariable("inputNickName") String inputNickName) {
		int row = memberService.nickNameDupCheck(inputNickName);
		String msg = row == 1 ? "이미 사용중인 닉네임 입니다" : "멋진 닉네임이에요!!";
		msg = row + ":" + msg;
		return msg;
	}
	
	@PostMapping("/member/kakao/callback")
	@ResponseBody
	public int kakao_login(@RequestBody MemberDTO dto, HttpSession session, String url, HttpServletRequest req, RedirectAttributes rttr, Model model) {
		int row = memberService.dupCheck(dto.getUserEmail());
		if(row == 1) {
			String ip = req.getHeader("X-FORWARDED-FOR");

	        if (ip == null) {
	            ip = req.getRemoteAddr();
	        }
			session.setAttribute("ip", ip);
			MemberDTO login = memberService.loginKakao(dto);
			session.setAttribute("member", login);
			session.setAttribute("userIdx", login.getUserIdx());
		} else {
			model.addAttribute("dto", dto);
			session.setAttribute("member", null);
		}
		return row;
	}
	
	// 이메일 인증 ajax
	@GetMapping("/email_auth/{inputEmail}/")
	@ResponseBody
	public int email_auth(@PathVariable("inputEmail") String inputEmail) throws IOException {
		Random ran = new Random();
		String authNumber =ran.nextInt(10000000) + 10000000 + "";
		System.out.println(authNumber);
		int row = memberService.sendMail(inputEmail , authNumber);
		if(row == 1) {
			authNumberMap.put(inputEmail, authNumber);
		}
		return row;
	}
	
	// 인증번호 확인 ajax POST로 처리
	@PostMapping("/sendAuthNumber")
	@ResponseBody
	public int email_check(@RequestBody HashMap<String, String> param) {
		
		String storedAuthNumber = authNumberMap.get(param.get("email"));
		
		String inputAuthNumber = param.get("authNumber");
		
		boolean flag = storedAuthNumber.equals(inputAuthNumber);
		return flag ? 1 : 0;
	}
	
	// 회원IDX별 comments 불러오기
	@PostMapping("/admin/member_management/{userIdx}")
	public String member_management(@PathVariable("userIdx")int userIdx) throws IOException {
		List<CommentsDTO> list = adminService.getUserCommentsList(userIdx);
		return mapper.writeValueAsString(list);
		
	}
	
	@GetMapping("/dupCheckFind/{inputId}/")
	@ResponseBody
	public String dupCheck_find(@PathVariable("inputId") String inputId) {
		int row = memberService.dupCheck(inputId);
		if(inputId == "200") {
			int row2 = 1;
			String msg2 = "아이디를 입력하세요";
			msg2 = row2 + ":" + msg2;
			return msg2;
		}
		String msg = row == 1 ? "인증번호 발송이 가능합니다" : "인증번호를 보낼 수 없습니다  이메일을 확인해주세요";
		msg = row + ":" + msg;
		return msg;
	}
	
	// 이메일 인증 ajax
	@GetMapping("/email_find/{inputEmail}/")
	@ResponseBody
	public int email_find(@PathVariable("inputEmail") String inputEmail) throws IOException {
		String userPw = getRamdomPassword();
		System.out.println(userPw);
		memberService.findSetPw(inputEmail, userPw);
		int row = memberService.sendMailsetPw(inputEmail , userPw);
		if(row == 1) {
			authNumberMap.put(inputEmail, userPw);
		}
		return row;
	}
	
    public String getRamdomPassword() {
    	int size = 12;
        char[] charSet = new char[] {
                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
                '!', '@', '#', '$', '%', '^', '&' };

        StringBuffer sb = new StringBuffer();
        SecureRandom sr = new SecureRandom();
        sr.setSeed(new Date().getTime());

        int idx = 0;
        int len = charSet.length;
        for (int i=0; i<size; i++) {
            idx = sr.nextInt(len);    // 강력한 난수를 발생시키기 위해 SecureRandom을 사용한다.
            sb.append(charSet[idx]);
        }
        
        return sb.toString();
    }
    
    @RequestMapping("/chart")
    public List<RecipeCountDTO> homeChart() {
    	List<RecipeCountDTO> chart = recipeCountService.getMainIngList();
    	return chart;
    }
    
    @GetMapping("/heartChange/{recipeIdx}/{loginUserIdx}")
    public int heartChange(@PathVariable("recipeIdx") int recipeIdx, @PathVariable("loginUserIdx") int userIdx) {
    	int row = heartService.insertHeart(recipeIdx, userIdx);
    	return row;
    }
    
    @GetMapping("/heartChangeDelete/{recipeIdx}/{loginUserIdx}")
    public int heartChangeDelete(@PathVariable("recipeIdx") int recipeIdx, @PathVariable("loginUserIdx") int userIdx) {
    	int row = heartService.deleteHeart(recipeIdx, userIdx);
    	return row;
    }
    
	@PostMapping("/member/myPageCheck/{userIdx}/")
	@ResponseBody
	public int myPageCheck(@PathVariable("userIdx") int userIdx, @RequestBody MemberDTO dto) {
		dto.setUserPw(hashComponent.getHash(dto.getUserPw()));
		dto.setUserIdx(userIdx);
		int row = memberService.showMypage(dto);
		return row;
	}
	
	
	
	

}
