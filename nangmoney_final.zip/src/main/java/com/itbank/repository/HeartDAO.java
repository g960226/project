package com.itbank.repository;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface HeartDAO {

	int insertHeart(@Param("recipeIdx") int recipeIdx, @Param("userIdx") int userIdx);

	int deleteHeart(@Param("recipeIdx") int recipeIdx, @Param("userIdx") int userIdx);

}
