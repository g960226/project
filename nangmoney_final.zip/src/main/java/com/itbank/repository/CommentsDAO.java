package com.itbank.repository;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.itbank.model.CommentsDTO;

@Repository
public interface CommentsDAO {

	List<CommentsDTO> selectUserCommentsList(int userIdx);
	
	int delete_comments(int commentsIdx);

	List<CommentsDTO> getCommentsList(int recipeIdx);

	int writeComments(CommentsDTO dto);

	CommentsDTO commentsSelectOne(int commentsIdx);

	Double getScoreAvg(int recipeIdx);

	void updateScoreAvg(HashMap<String, Object> param);

	int getUserSum(int recipeIdx);

	void updateUserSum(HashMap<String, Object> param2);

	int getRecipeIdx(int commentsIdx);
}
