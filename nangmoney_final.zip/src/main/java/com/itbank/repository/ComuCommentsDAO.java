package com.itbank.repository;

import java.util.List;

import com.itbank.model.ComuCommentsDTO;

public interface ComuCommentsDAO {

	List<ComuCommentsDTO> getCommentsList(int communityIdx);

	int writeComments(ComuCommentsDTO dto);

	int delete_comments(int comuCommentsIdx);

}
