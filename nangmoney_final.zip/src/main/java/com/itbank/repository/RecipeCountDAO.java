package com.itbank.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.itbank.model.RecipeCountDTO;

@Repository
public interface RecipeCountDAO {

	RecipeCountDTO getRecipeDataList();

	void setRecipeCountData(RecipeCountDTO rcDto);

	List<RecipeCountDTO> getMainIngData();
	
	

}
