package com.itbank.repository;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.itbank.model.CategoryDTO;
import com.itbank.model.RecipeDTO;

@Repository
public interface RecipeDAO {

	int insert_recipe(RecipeDTO dto);

	RecipeDTO selectOne_recipe(int recipeIdx);

	int update_recipe(RecipeDTO dto);

	List<RecipeDTO> getSearchRecipe(String recipeName);
	
	int delete_recipe(int recipeIdx);
	
	List<RecipeDTO> getList();
	
	int addCategory(CategoryDTO dto2);

	List<RecipeDTO> selectList_video();
	
	int selectRecentRecipeIdx();

	List<CategoryDTO> getSearchCategory();

	int modifyCategory(RecipeDTO dto);
	
	List<RecipeDTO> getPopList();

	List<RecipeDTO> getRecipeList();

	List<RecipeDTO> selectIngredient(CategoryDTO dto);

	int updateViews(int recipeIdx);
	
	//===========================================
	int getBeef();

	int getPork();

	int getChicken();

	int getMeat();

	int getHam();

	int getSalmon();

	int getTuna();

	int getNoodle();

	int getSeafood();

	int getBread();

	int getAlage();

	int getTofu();

	int getFishcake();

	int getKimchi();

	int getOnion();

	int getMushroom();

	int getEgg();

	int getGarlic();

	int getGreenOnion();

	int getPotato();

	int getPepper();

	int getSquash();

	int getVegetables();

	int getMiso();

	int getChiliPepperPaste();

	int getSoySauce();

	int getTomatoSauce();

	int getButter();

	int getMayonnaise();

	int getMara();

	int getKetchup();

	int getCondiment();

	int getCurry();

	int getJjajang();

	int getBronze();

	int getSilver();

	int getGold();

	int getMommyHand();
	// ====================================

	void updateHeart(int recipeIdx);

	void updateMinusHeart(int recipeIdx);

	Integer heartCheckRecipe(@Param("recipeIdx") int recipeIdx, @Param("userIdx") int userIdx);
	
	List<RecipeDTO> getLikeHeart(int userIdx);

}
