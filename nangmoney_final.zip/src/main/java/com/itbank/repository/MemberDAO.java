package com.itbank.repository;


import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import com.itbank.model.MemberDTO;


@Repository
public interface MemberDAO {

	void addMember(MemberDTO dto);

	int dupCheck(String inputId);

	int nicknameDupResult(String inputNickName);

	MemberDTO login(MemberDTO dto);

	List<MemberDTO> selectList_member();
	
	int delete_member(int userIdx);

	List<MemberDTO> getSearchMember(String userName);

	int modify(MemberDTO dto);

	MemberDTO getMypage(int userIdx);

	int modifyMypage(MemberDTO dto);

	void modifyPw(MemberDTO dto);

	int withdraw_member(int userIdx);

	void findSetPw(@Param("userEmail") String userEmail, @Param("userPw") String userPw);

	MemberDTO loginKakao(MemberDTO dto);

	int showMypage(MemberDTO dto);

}
