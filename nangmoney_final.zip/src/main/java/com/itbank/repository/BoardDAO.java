package com.itbank.repository;

import java.util.HashMap;
import java.util.List;

import com.itbank.model.AwardDTO;
import com.itbank.model.RecipeDTO;


public interface BoardDAO {

	List<RecipeDTO> selectListAll();

	List<RecipeDTO> selectNewrecipe();
	
	
	List<RecipeDTO> search(HashMap<String, Object> param);
	
	List<RecipeDTO> selectAll(HashMap<String, Object> param);

	int selectBoardCount();

	int selectSearchBoardCount(String recipeName);

	List<AwardDTO> getPopularAwardIng1();

	List<AwardDTO> getPopularAwardIng2();

	List<AwardDTO> getAge10Chart();
	
	List<AwardDTO> getAgeTwoChart();
	
	List<AwardDTO> getAgeThreeChart();
	
	List<AwardDTO> getAgeForeChart();
	
	List<AwardDTO> getAgeFiveChart();

	List<RecipeDTO> getPopularScore();

	List<RecipeDTO> getPopularLikeSum();
}
