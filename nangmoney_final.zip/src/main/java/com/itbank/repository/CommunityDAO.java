package com.itbank.repository;

import java.util.HashMap;
import java.util.List;

import com.itbank.model.CommunityDTO;
import com.itbank.model.CommunityUploadDTO;

public interface CommunityDAO {

	int selectSearchCommunityCount(String communityTitle);

	int selectCommunityCount();

	List<CommunityDTO> search(HashMap<String, Object> param);

	List<CommunityDTO> selectAll(HashMap<String, Object> param);

	void viewCount(int idx);

	CommunityDTO selectOne(int communityIdx);
	
	int write2(CommunityDTO dto);

	int insert(CommunityDTO dto);
	
	int selectLastIdx();

	int insertUploadImage(HashMap<String, Object> param);
	
	List<HashMap<String, String>> getCommunity(int offset);

	List<String> getImages(int idx);

	int modify(CommunityDTO dto);

	int delete(int idx);

	List<CommunityUploadDTO> getUploadFile(int communityIdx);

	int modify_upload(CommunityUploadDTO list);

	List<String> selectUploadFileNewName(int communityIdx);

	int deleteUploadfiles(int communityIdx);

	CommunityUploadDTO getImage(int imageIdx);

	int modify_uploadFile(CommunityUploadDTO dto);

	List<CommunityDTO> selectList_community();

}
