package com.itbank.interceptor;

import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.resource.ResourceHttpRequestHandler;

import com.itbank.repository.RecipeDAO;

public class CookieInterceptor extends HandlerInterceptorAdapter {


	@Autowired
	private RecipeDAO dao;

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
		if(handler instanceof ResourceHttpRequestHandler) {
			return;
		}
		
		Cookie[] arr = request.getCookies();
		String incomeCookieValue = "";

		if (arr != null) {
			for (Cookie newCookie : arr) {
				if ("recentList".equals(newCookie.getName())) {
					incomeCookieValue = newCookie.getValue();
				}
			}
		}
		ArrayList<String> list = new ArrayList<String>(Arrays.asList(incomeCookieValue.split("_")));
		list.removeIf(str -> str.equals(""));
		
		
		try {
			for(int i = 0; i < list.size(); i++) {
				// 썸네일 이름 불러와서 value에 저장 => key를 이용하여 부름
				String key = "recent" + (i + 1);
				
				String value = dao.selectOne_recipe(Integer.parseInt(list.get(i))).getRecipeThumbNail();
				// idx 값을 불러와서 value2에 저장
				String key2 = "idx" +(i +1);
				String value2 = list.get(i);
				System.out.println(key + " : " + value);
				HttpSession session = request.getSession();
				session.setAttribute(key, value);
				session.setAttribute(key2, value2);
			}
			
		} catch(NullPointerException e) {
			System.out.println(NullPointerException.class + " 예외 발생 무시");
		}
	}
}
