package com.itbank.model;

//CREATE TABLE category (
//		categoryIdx	Number	DEFAULT category_seq.nextval  primary key	NOT NULL,
//		recipeIdx	number	Unique	NOT NULL,
//		ingredient1	varchar2(100)	check(ingredient1 in('소고기', '돼지고기', '닭고기', '고기류', '햄', '연어', '참치', '면류', '해물류', '빵_밀가루', '해조류')) NULL,
//		ingredient2	varchar2(100)	check(ingredient2 in('두부', '어묵', '김치', '양파', '버섯', '유제품_계란', '마늘', '파', '감자', '고추', '애호박', '채소류'))	NULL,
//		ingredient3	varchar2(100)	check(ingredient3 in('된장', '고추장', '간장', '토마토소스', '버터', '마요네즈', '마라', '케찹', '조미료', '카레', '짜장'))	NULL,
//		hand	    varchar2(20)	    check(hand in('똥손', '은손', '금손', '마미손'))	NULL
//	);

public class CategoryDTO {
	private int categoryIdx;
	private int recipeIdx;
	private String ingredient1;
	private String ingredient2;
	private String ingredient3;
	private String hand;
	
	
	public int getCategoryIdx() {
		return categoryIdx;
	}
	public void setCategoryIdx(int categoryIdx) {
		this.categoryIdx = categoryIdx;
	}
	public int getRecipeIdx() {
		return recipeIdx;
	}
	public void setRecipeIdx(int recipeIdx) {
		this.recipeIdx = recipeIdx;
	}
	public String getIngredient1() {
		return ingredient1;
	}
	public void setIngredient1(String ingredient1) {
		this.ingredient1 = ingredient1;
	}
	public String getIngredient2() {
		return ingredient2;
	}
	public void setIngredient2(String ingredient2) {
		this.ingredient2 = ingredient2;
	}
	public String getIngredient3() {
		return ingredient3;
	}
	public void setIngredient3(String ingredient3) {
		this.ingredient3 = ingredient3;
	}
	public String getHand() {
		return hand;
	}
	public void setHand(String hand) {
		this.hand = hand;
	}
	
	

}
