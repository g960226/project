package com.itbank.model;

import org.springframework.web.multipart.MultipartFile;

public class CommunityUploadDTO {
	private int communityIdx;
	private int imageIdx;
	private String oldName;
	private String newName;
	private String communityContent;
	private MultipartFile modifyFile;
	
	public MultipartFile getModifyFile() {
		return modifyFile;
	}
	public void setModifyFile(MultipartFile modifyFile) {
		this.modifyFile = modifyFile;
	}
	public int getCommunityIdx() {
		return communityIdx;
	}
	public void setCommunityIdx(int communityIdx) {
		this.communityIdx = communityIdx;
	}
	public int getImageIdx() {
		return imageIdx;
	}
	public void setImageIdx(int imageIdx) {
		this.imageIdx = imageIdx;
	}
	public String getOldName() {
		return oldName;
	}
	public void setOldName(String oldName) {
		this.oldName = oldName;
	}
	public String getNewName() {
		return newName;
	}
	public void setNewName(String newName) {
		this.newName = newName;
	}
	public String getCommunityContent() {
		return communityContent;
	}
	public void setCommunityContent(String communityContent) {
		this.communityContent = communityContent;
	}
	
	
}
