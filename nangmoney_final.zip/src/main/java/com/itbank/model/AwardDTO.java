package com.itbank.model;

public class AwardDTO {

	private String age;
	private String ingredient1;
	private String ingredient2;
	private int countIng1;
	private int countIng2;
	private int ageCountIng1;
	private int ageCountIng2;
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getIngredient1() {
		return ingredient1;
	}
	public void setIngredient1(String ingredient1) {
		this.ingredient1 = ingredient1;
	}
	public String getIngredient2() {
		return ingredient2;
	}
	public void setIngredient2(String ingredient2) {
		this.ingredient2 = ingredient2;
	}
	public int getCountIng1() {
		return countIng1;
	}
	public void setCountIng1(int countIng1) {
		this.countIng1 = countIng1;
	}
	public int getCountIng2() {
		return countIng2;
	}
	public void setCountIng2(int countIng2) {
		this.countIng2 = countIng2;
	}
	public int getAgeCountIng1() {
		return ageCountIng1;
	}
	public void setAgeCountIng1(int ageCountIng1) {
		this.ageCountIng1 = ageCountIng1;
	}
	public int getAgeCountIng2() {
		return ageCountIng2;
	}
	public void setAgeCountIng2(int ageCountIng2) {
		this.ageCountIng2 = ageCountIng2;
	}
	
}
