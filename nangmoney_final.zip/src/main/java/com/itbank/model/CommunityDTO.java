package com.itbank.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class CommunityDTO {
	private int userIdx;
	private int communityIdx;
	private String nickName;
	private String communityTitle;
	private List<String> communityContent;
	private Date writeDate;
	private String ipaddr;
	private int communityViews;
	private String thumbnail;
	private MultipartFile thumbnailFile;
	private List<MultipartFile> myRecipeImage;
	private List<String> newNameList = new ArrayList<String>();
	
	
	
	
	public String getThumbnail() {
		return thumbnail;
	}
	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}
	public MultipartFile getThumbnailFile() {
		return thumbnailFile;
	}
	public void setThumbnailFile(MultipartFile thumbnailFile) {
		this.thumbnailFile = thumbnailFile;
	}
	public List<String> getCommunityContent() {
		return communityContent;
	}
	public void setCommunityContent(List<String> communityContent) {
		this.communityContent = communityContent;
	}
	public List<MultipartFile> getMyRecipeImage() {
		return myRecipeImage;
	}
	public void setMyRecipeImage(List<MultipartFile> myRecipeImage) {
		this.myRecipeImage = myRecipeImage;
	}
	public List<String> getNewNameList() {
		return newNameList;
	}
	public void setNewNameList(List<String> newNameList) {
		this.newNameList = newNameList;
	}
	public int getCommunityIdx() {
		return communityIdx;
	}
	public void setCommunityIdx(int communityIdx) {
		this.communityIdx = communityIdx;
	}
	
	public int getUserIdx() {
		return userIdx;
	}
	public void setUserIdx(int userIdx) {
		this.userIdx = userIdx;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getCommunityTitle() {
		return communityTitle;
	}
	public void setCommunityTitle(String communityTitle) {
		this.communityTitle = communityTitle;
	}

	public Date getWriteDate() {
		return writeDate;
	}
	public void setWriteDate(Date writeDate) {
		this.writeDate = writeDate;
	}
	public String getIpaddr() {
		return ipaddr;
	}
	public void setIpaddr(String ipaddr) {
		this.ipaddr = ipaddr;
	}
	public int getCommunityViews() {
		return communityViews;
	}
	public void setCommunityViews(int communityViews) {
		this.communityViews = communityViews;
	}
	
	
	
	
	
	
	
}
