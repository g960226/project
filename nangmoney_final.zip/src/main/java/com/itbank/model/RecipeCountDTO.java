package com.itbank.model;

public class RecipeCountDTO {
	private int beef;
	private int pork;
	private int chicken;
	private int meat;
	private int ham;
	private int salmon;
	private int tuna;
	private int noodle;
	private int seafood;
	private int bread;
	private int algae;
	private int tofu;
	private int fishCake;
	private int kimchi;
	private int onion;
	private int mushroom;
	private int egg;
	private int garlic;
	private int greenOnion;
	private int potato;
	private int pepper;
	private int squash;
	private int vegetables;
	private int miso;
	private int chiliPepperPaste;
	private int soySauce;
	private int tomatoSauce;
	private int butter;
	private int mayonnaise;
	private int mara;
	private int ketchup;
	private int condiment;
	private int curry;
	private int jjajang;
	private int bronze;
	private int silver;
	private int gold;
	private int mommyHand;
	
	
	public int getBeef() {
		return beef;
	}
	public void setBeef(int beef) {
		this.beef = beef;
	}
	public int getPork() {
		return pork;
	}
	public void setPork(int pork) {
		this.pork = pork;
	}
	public int getChicken() {
		return chicken;
	}
	public void setChicken(int chicken) {
		this.chicken = chicken;
	}
	public int getMeat() {
		return meat;
	}
	public void setMeat(int meat) {
		this.meat = meat;
	}
	public int getHam() {
		return ham;
	}
	public void setHam(int ham) {
		this.ham = ham;
	}
	public int getSalmon() {
		return salmon;
	}
	public void setSalmon(int salmon) {
		this.salmon = salmon;
	}
	public int getTuna() {
		return tuna;
	}
	public void setTuna(int tuna) {
		this.tuna = tuna;
	}
	public int getNoodle() {
		return noodle;
	}
	public void setNoodle(int noodle) {
		this.noodle = noodle;
	}
	public int getSeafood() {
		return seafood;
	}
	public void setSeafood(int seafood) {
		this.seafood = seafood;
	}
	public int getBread() {
		return bread;
	}
	public void setBread(int bread) {
		this.bread = bread;
	}
	public int getAlgae() {
		return algae;
	}
	public void setAlgae(int algae) {
		this.algae = algae;
	}
	public int getTofu() {
		return tofu;
	}
	public void setTofu(int tofu) {
		this.tofu = tofu;
	}
	public int getFishCake() {
		return fishCake;
	}
	public void setFishCake(int fishCake) {
		this.fishCake = fishCake;
	}
	public int getKimchi() {
		return kimchi;
	}
	public void setKimchi(int kimchi) {
		this.kimchi = kimchi;
	}
	public int getOnion() {
		return onion;
	}
	public void setOnion(int onion) {
		this.onion = onion;
	}
	public int getMushroom() {
		return mushroom;
	}
	public void setMushroom(int mushroom) {
		this.mushroom = mushroom;
	}
	public int getEgg() {
		return egg;
	}
	public void setEgg(int egg) {
		this.egg = egg;
	}
	public int getGarlic() {
		return garlic;
	}
	public void setGarlic(int garlic) {
		this.garlic = garlic;
	}
	public int getGreenOnion() {
		return greenOnion;
	}
	public void setGreenOnion(int greenOnion) {
		this.greenOnion = greenOnion;
	}
	public int getPotato() {
		return potato;
	}
	public void setPotato(int potato) {
		this.potato = potato;
	}
	public int getPepper() {
		return pepper;
	}
	public void setPepper(int pepper) {
		this.pepper = pepper;
	}
	public int getSquash() {
		return squash;
	}
	public void setSquash(int squash) {
		this.squash = squash;
	}
	public int getVegetables() {
		return vegetables;
	}
	public void setVegetables(int vegetables) {
		this.vegetables = vegetables;
	}
	public int getMiso() {
		return miso;
	}
	public void setMiso(int miso) {
		this.miso = miso;
	}
	public int getChiliPepperPaste() {
		return chiliPepperPaste;
	}
	public void setChiliPepperPaste(int chiliPepperPaste) {
		this.chiliPepperPaste = chiliPepperPaste;
	}
	public int getSoySauce() {
		return soySauce;
	}
	public void setSoySauce(int soySauce) {
		this.soySauce = soySauce;
	}
	public int getTomatoSauce() {
		return tomatoSauce;
	}
	public void setTomatoSauce(int tomatoSauce) {
		this.tomatoSauce = tomatoSauce;
	}
	public int getButter() {
		return butter;
	}
	public void setButter(int butter) {
		this.butter = butter;
	}
	public int getMayonnaise() {
		return mayonnaise;
	}
	public void setMayonnaise(int mayonnaise) {
		this.mayonnaise = mayonnaise;
	}
	public int getMara() {
		return mara;
	}
	public void setMara(int mara) {
		this.mara = mara;
	}
	public int getKetchup() {
		return ketchup;
	}
	public void setKetchup(int ketchup) {
		this.ketchup = ketchup;
	}
	public int getcondiment() {
		return condiment;
	}
	public void setcondiment(int condiment) {
		this.condiment = condiment;
	}
	public int getCurry() {
		return curry;
	}
	public void setCurry(int curry) {
		this.curry = curry;
	}
	public int getJjajang() {
		return jjajang;
	}
	public void setJjajang(int jjajang) {
		this.jjajang = jjajang;
	}
	public int getBronze() {
		return bronze;
	}
	public void setBronze(int bronze) {
		this.bronze = bronze;
	}
	public int getSilver() {
		return silver;
	}
	public void setSilver(int silver) {
		this.silver = silver;
	}
	public int getGold() {
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
	}
	public int getMommyHand() {
		return mommyHand;
	}
	public void setMommyHand(int mommyHand) {
		this.mommyHand = mommyHand;
	}
	
	
	

}
