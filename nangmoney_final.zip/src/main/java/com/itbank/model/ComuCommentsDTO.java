package com.itbank.model;

import java.sql.Date;

public class ComuCommentsDTO {

	private int comuCommentsIdx;
	private int communityIdx;
	private int userIdx;
	private String nickName;
	private String comuMemo;
	private Date comuCommentsDate;
	
	private int parent_idx;
	private int reply_depth;
	
	
	
	public int getParent_idx() {
		return parent_idx;
	}
	public void setParent_idx(int parent_idx) {
		this.parent_idx = parent_idx;
	}
	public int getReply_depth() {
		return reply_depth;
	}
	public void setReply_depth(int reply_depth) {
		this.reply_depth = reply_depth;
	}
	public int getComuCommentsIdx() {
		return comuCommentsIdx;
	}
	public void setComuCommentsIdx(int comuCommentsIdx) {
		this.comuCommentsIdx = comuCommentsIdx;
	}
	public int getCommunityIdx() {
		return communityIdx;
	}
	public void setCommunityIdx(int communityIdx) {
		this.communityIdx = communityIdx;
	}
	public int getUserIdx() {
		return userIdx;
	}
	public void setUserIdx(int userIdx) {
		this.userIdx = userIdx;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getComuMemo() {
		return comuMemo;
	}
	public void setComuMemo(String comuMemo) {
		this.comuMemo = comuMemo;
	}
	public Date getComuCommentsDate() {
		return comuCommentsDate;
	}
	public void setComuCommentsDate(Date comuCommentsDate) {
		this.comuCommentsDate = comuCommentsDate;
	}	
	
	
}
