package com.itbank.model;

public class LikeHeartDTO {
	private int likeHeartIdx;
	private int recipeIdx;
	private int userIdx;
	
	public int getLikeHeartIdx() {
		return likeHeartIdx;
	}
	public void setLikeHeartIdx(int likeHeartIdx) {
		this.likeHeartIdx = likeHeartIdx;
	}
	public int getRecipeIdx() {
		return recipeIdx;
	}
	public void setRecipeIdx(int recipeIdx) {
		this.recipeIdx = recipeIdx;
	}
	public int getUserIdx() {
		return userIdx;
	}
	public void setUserIdx(int userIdx) {
		this.userIdx = userIdx;
	}
	
}
