package com.itbank.model;

import java.sql.Date;

import org.springframework.web.multipart.MultipartFile;

//CREATE TABLE recipe (
//		recipeIdx	        number	DEFAULT     recipe_seq.nextval primary key,
//		recipeName	        varchar2(100)		NOT NULL,
//		recipeURL	        varchar2(255)		NOT NULL,
//		recipeThumbNail	    varchar2(200)		NOT NULL,
//		score	            number(2,1)		    	NULL,
//		scoreUserSum	    number		        NULL,
//		views	            number		        NULL,
//		registerDate        date                default sysdate not null,
//		recipeSourceCode	varchar2(1000)		NOT NULL
//	);

public class RecipeDTO {
	
	private int recipeIdx;
	private String recipeName;
	private String recipeURL;
	private String recipeThumbNail;
	private MultipartFile uploadThumbNail;
	private double score;
	private int scoreUserSum;
	private double scoreAvg;
	private int views;
	private Date registerDate;
	private String recipeSourceCode;
	private String ingredient1;
	private String ingredient2;
	private String ingredient3;
	private String hand;
	private int likeSum;
	private int heartCheck;
	
	
	public String getHand() {
		return hand;
	}
	public void setHand(String hand) {
		this.hand = hand;
	}
	public String getIngredient1() {
		return ingredient1;
	}
	public void setIngredient1(String ingredient1) {
		this.ingredient1 = ingredient1;
	}
	public String getIngredient2() {
		return ingredient2;
	}
	public void setIngredient2(String ingredient2) {
		this.ingredient2 = ingredient2;
	}
	public String getIngredient3() {
		return ingredient3;
	}
	public void setIngredient3(String ingredient3) {
		this.ingredient3 = ingredient3;
	}
	public MultipartFile getUploadThumbNail() {
		return uploadThumbNail;
	}
	public void setUploadThumbNail(MultipartFile uploadThumbNail) {
		this.uploadThumbNail = uploadThumbNail;
	}
	public int getRecipeIdx() {
		return recipeIdx;
	}
	public void setRecipeIdx(int recipeIdx) {
		this.recipeIdx = recipeIdx;
	}
	public String getRecipeName() {
		return recipeName;
	}
	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}
	public String getRecipeURL() {
		return recipeURL;
	}
	public void setRecipeURL(String recipeURL) {
		this.recipeURL = recipeURL;
	}
	public String getRecipeThumbNail() {
		return recipeThumbNail;
	}
	public void setRecipeThumbNail(String recipeThumbNail) {
		this.recipeThumbNail = recipeThumbNail;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public int getScoreUserSum() {
		return scoreUserSum;
	}
	public void setScoreUserSum(int scoreUserSum) {
		this.scoreUserSum = scoreUserSum;
	}
	public int getViews() {
		return views;
	}
	public void setViews(int views) {
		this.views = views;
	}
	public Date getRegisterDate() {
		return registerDate;
	}
	public void setRegisterDate(Date registerDate) {
		this.registerDate = registerDate;
	}
	public String getRecipeSourceCode() {
		return recipeSourceCode;
	}
	public void setRecipeSourceCode(String recipeSourceCode) {
		this.recipeSourceCode = recipeSourceCode;
	}
	public double getScoreAvg() {
		return scoreAvg;
	}
	public void setScoreAvg(double scoreAvg) {
		this.scoreAvg = scoreAvg;
	}
	public int getLikeSum() {
		return likeSum;
	}
	public void setLikeSum(int likeSum) {
		this.likeSum = likeSum;
	}
	public int getHeartCheck() {
		return heartCheck;
	}
	public void setHeartCheck(int heartCheck) {
		this.heartCheck = heartCheck;
	}
	
}
