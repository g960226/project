package com.itbank.model;

import java.sql.Date;

//	COMMENTIDX   NOT NULL NUMBER        
//	RECIPEIDX    NOT NULL NUMBER        
//	USERIDX      NOT NULL NUMBER        
//	NICKNAME     NOT NULL VARCHAR2(100) 
//	SCORE        NOT NULL NUMBER(1)     
//	MEMO                  VARCHAR2(500) 
//	COMMENTSDATE NOT NULL DATE
public class CommentsDTO {
	
	private int commentsIdx;
	private int recipeIdx;
	private String recipeName;
	private int userIdx;
	private String nickName;
	private int score;
	private String memo;
	private Date commentsDate;
	
	public int getCommentsIdx() {
		return commentsIdx;
	}
	public void setCommentsIdx(int commentsIdx) {
		this.commentsIdx = commentsIdx;
	}
	public int getRecipeIdx() {
		return recipeIdx;
	}
	public void setRecipeIdx(int recipeIdx) {
		this.recipeIdx = recipeIdx;
	}
	public int getUserIdx() {
		return userIdx;
	}
	public void setUserIdx(int userIdx) {
		this.userIdx = userIdx;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public Date getCommentsDate() {
		return commentsDate;
	}
	public void setCommentsDate(Date commentsDate) {
		this.commentsDate = commentsDate;
	}
	public String getRecipeName() {
		return recipeName;
	}
	public void setRecipeName(String recipeName) {
		this.recipeName = recipeName;
	}

}
