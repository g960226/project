package card;

public class Card {
	char type;	// 다이아, 스페이드, 클로버, 하트
	char num;	// A, 2, 3, 4, 5, 6, 7, 8, 9, 10, J, Q, K
	
	int width; 	// 카드의 너비
	int height;	// 카드의 높이
	
	Card(char type, char num) { // 생성자
		
	}
	
	void show() { // 카드 출력 함수
		
		
		
		
		
	}
	
}
